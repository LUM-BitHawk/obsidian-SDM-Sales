@echo off
REM Obsidian-Agent SDM - Einrichtung (Windows). Mehrfach ausfuehrbar, keine Adminrechte noetig.
REM Optional: Sprache als Parameter, z.B.  installieren.bat fr
cd /d "%~dp0"
if "%~1"=="" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installieren.ps1"
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installieren.ps1" -Sprache %~1
)
