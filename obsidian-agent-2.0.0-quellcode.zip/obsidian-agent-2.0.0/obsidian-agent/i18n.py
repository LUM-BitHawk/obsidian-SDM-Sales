"""
Übersetzungen. Deutsch ist die Mastersprache: Der deutsche Text ist zugleich der Schlüssel.
Die anderen Sprachen liegen als JSON in i18n/<code>.json ({"Deutscher Text": "Übersetzung"}).
Fehlt eine Übersetzung, erscheint der deutsche Text.
"""
from __future__ import annotations

import json
from pathlib import Path

SPRACHEN = {
    "de": "Deutsch",
    "en": "English",
    "fr": "Français",
    "it": "Italiano",
    "es": "Español",
    "ro": "Română",
}
STANDARD = "de"
_DIR = Path(__file__).resolve().parent / "i18n"
_CACHE: dict[str, dict[str, str]] = {}

# Datums- und Zahlenformat je Sprache
DATUM_FORMAT = {"de": "%d.%m.%Y", "en": "%d/%m/%Y", "fr": "%d/%m/%Y",
                "it": "%d/%m/%Y", "es": "%d/%m/%Y", "ro": "%d.%m.%Y"}
TAUSENDER = {"de": "'", "en": ",", "fr": " ", "it": ".", "es": ".", "ro": "."}
HTML_LANG = {"de": "de-CH", "en": "en", "fr": "fr", "it": "it", "es": "es", "ro": "ro"}


def norm_sprache(code: str | None) -> str:
    code = (code or "").strip().lower()[:2]
    return code if code in SPRACHEN else STANDARD


def tabelle(sprache: str) -> dict[str, str]:
    sprache = norm_sprache(sprache)
    if sprache == STANDARD:
        return {}
    if sprache not in _CACHE:
        f = _DIR / f"{sprache}.json"
        _CACHE[sprache] = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    return _CACHE[sprache]


def t(sprache: str, text: str, **werte) -> str:
    s = tabelle(sprache).get(text) or text
    return s.format(**werte) if werte else s


def zahl(sprache: str, v, nachkomma: int = 0) -> str:
    try:
        s = f"{float(v):,.{nachkomma}f}"
    except (TypeError, ValueError):
        return "–"
    tausender = TAUSENDER[norm_sprache(sprache)]
    dezimal = "." if tausender in ("'", ",") else ","
    return s.replace(",", "\0").replace(".", dezimal).replace("\0", tausender)
