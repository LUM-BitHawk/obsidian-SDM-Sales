"""
Obsidian-Agent SDM – lokale Weboberfläche
Start:  python app.py   ->  http://127.0.0.1:5055
"""
from __future__ import annotations

import datetime as dt
import os
import threading
import webbrowser

from flask import Flask, abort, flash, redirect, render_template, request, url_for

import agent as core
import i18n

app = Flask(__name__)
app.secret_key = os.environ.get("OBSIDIAN_AGENT_SECRET") or os.urandom(24).hex()
AGENT = core.Agent()


def _(text: str, **kw) -> str:
    return AGENT._(text, **kw)


@app.template_filter("dmy")
def _dmy(v):
    return AGENT.dmy(v)


@app.template_filter("zahl")
def _zahl(v):
    return i18n.zahl(AGENT.sprache, v)


@app.template_filter("lc_pos")
def _lc_pos(tage):
    if tage is None:
        return 100.0
    return round(max(0, min(tage, 730)) / 730 * 100, 1)


@app.context_processor
def _globals():
    return {"_": _, "heute": dt.date.today(), "cfg": AGENT.cfg, "vault_ok": AGENT.vault_ok(),
            "letzter_sync": AGENT.letzter_sync(), "sprache": AGENT.sprache, "SPRACHEN": i18n.SPRACHEN,
            "html_lang": i18n.HTML_LANG[AGENT.sprache], "label": AGENT.label, "PHASE_TEXT": core.PHASE_TEXT,
            "WAEHRUNG": AGENT.cfg.get("waehrung") or "CHF", "core": core}


@app.before_request
def _vault_pruefen():
    if request.endpoint in ("einstellungen", "sprache_wechseln", "static") or AGENT.vault_ok():
        return None
    flash(_("Vault-Ordner nicht gefunden: {pfad} – bitte in den Einstellungen setzen.", pfad=AGENT.vault), "fehler")
    return redirect(url_for("einstellungen"))


def _aktion(fn, ok_text: str, ziel: str):
    try:
        p = fn()
        flash(_(ok_text, pfad=AGENT.rel(p) if p else ""), "ok")
    except Exception as exc:
        flash(str(exc), "fehler")
    return redirect(ziel)


def _zurueck(standard: str) -> str:
    ref = request.form.get("zurueck") or request.referrer or ""
    return ref if ref.startswith("/") or ref.startswith(request.host_url) else url_for(standard)


# --- Heute ---------------------------------------------------------------------------
@app.route("/")
def heute():
    h = dt.date.today()
    n = int(AGENT.cfg.get("demnaechst_tage", 7))
    auf = AGENT.aufgaben(h)
    assets = AGENT.assets(h)
    opps = AGENT.opportunities(h)
    meet = [m for m in AGENT.meetings() if m["datum_d"] and 0 <= (m["datum_d"] - h).days <= n]
    meet.sort(key=lambda m: m["datum_d"])
    alle_kunden = AGENT.kunden(h)
    return render_template(
        "heute.html",
        faellig=[t for t in auf if t["gruppe"] in ("ueberfaellig", "heute")],
        bald=[t for t in auf if t["gruppe"] == "geplant" and t["rest"] <= n],
        lc=[a for a in assets if a["lc"]["klasse"] in ("abgelaufen", "umsetzung", "angebot")],
        opps_ueber=[o for o in opps if o["ueberfaellig"]],
        meetings=meet, kunden=alle_kunden, kunden_rot=[k for k in alle_kunden if k["status"] == "rot"], n=n)


@app.post("/sync")
def sync():
    try:
        s = AGENT.sync("manuell")
        flash(_("Aktualisiert: {dateien} Dateien gelesen, {faellig} Aufgaben fällig ({ms} ms).",
                dateien=s["dateien"], faellig=s["aufgaben_faellig"], ms=s["dauer_ms"]), "ok")
    except Exception as exc:
        flash(str(exc), "fehler")
    return redirect(_zurueck("heute"))


# --- Kunden ---------------------------------------------------------------------------
@app.route("/kunden")
def kunden():
    h = dt.date.today()
    alle = AGENT.kunden(h)
    q = request.args.get("q", "").strip().lower()
    sla = request.args.get("sla", "")
    status = request.args.get("status", "")
    liste = [k for k in alle if (not q or q in k["name"].lower() or q in (k.get("branche") or "").lower())
             and (not sla or k["sla"] == sla) and (not status or k["status"] == status)]
    vertraege = sum(1 for k in alle if k["vertragsende_d"] and 0 <= (k["vertragsende_d"] - h).days <= 365)
    return render_template("kunden.html", kunden=liste, alle=alle, q=q, sla_filter=sla, status_filter=status,
                           vertraege_12mt=vertraege)


@app.post("/kunden/neu")
def kunde_neu():
    return _aktion(lambda: AGENT.kunde_anlegen(request.form), "Angelegt: {pfad}", url_for("kunden"))


@app.route("/kunde/<key>")
def kunde(key):
    k = AGENT.kunde(key)
    if not k:
        abort(404)
    tab = request.args.get("tab", "assets")
    return render_template("kunde.html", k=k, tab=tab)


@app.post("/kunde/<key>/kontakt")
def kontakt_neu(key):
    return _aktion(lambda: AGENT.kontakt_anlegen({**request.form, "kunde": key}), "Angelegt: {pfad}",
                   url_for("kunde", key=key, tab="kontakte"))


@app.post("/kunde/<key>/eskalation")
def eskalation_neu(key):
    return _aktion(lambda: AGENT.eskalation_anlegen({**request.form, "kunde": key}), "Angelegt: {pfad}",
                   url_for("kunde", key=key))


# --- Lifecycle ------------------------------------------------------------------------
@app.route("/lifecycle")
def lifecycle():
    kat = request.args.get("kategorie", "")
    phase = request.args.get("phase", "")
    kunde_f = request.args.get("kunde", "")
    alle = AGENT.assets()
    liste = [a for a in alle if (not kat or a["kategorie_c"] == kat) and (not phase or a["lc"]["klasse"] == phase)
             and (not kunde_f or a["kunde_key"] == kunde_f)]
    zaehler = {p: sum(a["lc"]["klasse"] == p for a in alle) for p in core.PHASE_RANG}
    return render_template("lifecycle.html", assets=liste, kat=kat, phase=phase, kunde_f=kunde_f,
                           zaehler=zaehler, kunden=AGENT.kunden())


@app.post("/lifecycle/neu")
def asset_neu():
    return _aktion(lambda: AGENT.asset_anlegen(request.form), "Angelegt: {pfad}", _zurueck("lifecycle"))


# --- Pipeline -------------------------------------------------------------------------
@app.route("/pipeline")
def pipeline():
    h = dt.date.today()
    kunde_f = request.args.get("kunde", "")
    quelle = request.args.get("quelle", "")
    alle = AGENT.opportunities(h)
    liste = [o for o in alle if (not kunde_f or o["kunde_key"] == kunde_f) and (not quelle or o["quelle_c"] == quelle)]
    spalten = {p: [o for o in liste if o["phase"] == p] for p in core.OPP_PHASEN}
    offen = [o for o in liste if o["phase"] not in ("gewonnen", "verloren")]
    jahr = h - dt.timedelta(days=365)
    kpi = {"offen": sum(o["volumen"] for o in offen), "gewichtet": sum(o["gewichtet"] for o in offen),
           "aus_lifecycle": round(100 * sum(o["volumen"] for o in offen if o["quelle_c"] == "lifecycle")
                                  / max(1, sum(o["volumen"] for o in offen))) if offen else 0,
           "ueberfaellig": sum(o["ueberfaellig"] for o in liste),
           "gewonnen": sum(o["volumen"] for o in spalten["gewonnen"]
                           if not o["abschluss"] or o["abschluss"] >= jahr),
           "lc_ohne_opp": sum(1 for a in AGENT.assets(h)
                              if a["lc"]["klasse"] in ("abgelaufen", "umsetzung", "angebot") and not a["opportunity"])}
    return render_template("pipeline.html", spalten=spalten, kpi=kpi, kunde_f=kunde_f, quelle=quelle,
                           kunden=AGENT.kunden(h), asset_vorschlag=request.args.get("asset", ""),
                           assets=AGENT.assets(h))


@app.post("/pipeline/neu")
def opportunity_neu():
    return _aktion(lambda: AGENT.opportunity_anlegen(request.form), "Angelegt: {pfad}", _zurueck("pipeline"))


@app.post("/pipeline/phase")
def opportunity_phase():
    try:
        AGENT.opportunity_phase(request.form["pfad"], request.form["phase"])
    except Exception as exc:
        flash(str(exc), "fehler")
    return redirect(_zurueck("pipeline"))


# --- Meetings -------------------------------------------------------------------------
@app.route("/meetings")
def meetings():
    h = dt.date.today()
    kunde_f = request.args.get("kunde", "")
    alle = [m for m in AGENT.meetings() if not kunde_f or m["kunde_key"] == kunde_f]
    kommend = sorted([m for m in alle if m["datum_d"] and m["datum_d"] >= h], key=lambda m: m["datum_d"])
    vergangen = [m for m in alle if not m["datum_d"] or m["datum_d"] < h]
    return render_template("meetings.html", kommend=kommend, vergangen=vergangen[:60], kunde_f=kunde_f,
                           kunden=AGENT.kunden(h))


@app.post("/meetings/neu")
def meeting_neu():
    return _aktion(lambda: AGENT.meeting_anlegen(request.form), "Angelegt: {pfad}", _zurueck("meetings"))


# --- Aufgaben -------------------------------------------------------------------------
@app.route("/aufgaben")
def aufgaben():
    kunde_f = request.args.get("kunde", "")
    alle = AGENT.aufgaben(kunde=kunde_f)
    gruppen = {g: [t for t in alle if t["gruppe"] == g]
               for g in ("ueberfaellig", "heute", "geplant", "ohne_datum", "erledigt")}
    gruppen["erledigt"].sort(key=lambda t: t["roh"], reverse=True)
    return render_template("aufgaben.html", g=gruppen, kunde_f=kunde_f, kunden=AGENT.kunden())


@app.post("/aufgaben/neu")
def aufgabe_neu():
    f = request.form
    ziel = f.get("ziel", "")
    if not ziel and f.get("kunde"):
        k = AGENT.kunde_finden(f["kunde"])
        ziel = k["pfad"] if k else ""
    return _aktion(lambda: AGENT.aufgabe_anlegen(f.get("text", ""), f.get("faellig", ""), ziel),
                   "Aufgabe gespeichert in {pfad}", _zurueck("aufgaben"))


@app.post("/aufgaben/umschalten")
def aufgabe_umschalten():
    f = request.form
    try:
        AGENT.aufgabe_umschalten(f["pfad"], int(f["zeile"]), f["roh"])
    except Exception as exc:
        flash(str(exc), "fehler")
    return redirect(_zurueck("aufgaben"))


# --- Suche ----------------------------------------------------------------------------
@app.route("/suche")
def suche():
    q = request.args.get("q", "").strip()
    return render_template("suche.html", q=q, treffer=AGENT.suche(q) if q else None)


# --- Einstellungen --------------------------------------------------------------------
FELDER = ["vault_path", *core.ORDNER_KEYS, "waehrung", "sync_zeit", "demnaechst_tage"]


@app.route("/einstellungen", methods=["GET", "POST"])
def einstellungen():
    if request.method == "POST":
        for k in FELDER:
            if k in request.form:
                v = request.form[k].strip()
                AGENT.cfg[k] = int(v) if k == "demnaechst_tage" and v.isdigit() else v
        core.save_config(AGENT.cfg)
        if request.form.get("sprache") and request.form["sprache"] != AGENT.sprache:
            AGENT.sprache_setzen(request.form["sprache"])
        if AGENT.vault_ok():
            try:
                if request.form.get("vorlagen_neu"):
                    AGENT.vorlagen_schreiben(ueberschreiben=True)
                AGENT.sync("manuell")
                flash(_("Einstellungen gespeichert und Vault eingelesen."), "ok")
            except Exception as exc:
                flash(str(exc), "fehler")
        else:
            flash(_("Gespeichert – aber der Vault-Ordner existiert nicht: {pfad}", pfad=AGENT.vault), "fehler")
        return redirect(url_for("einstellungen"))
    return render_template("einstellungen.html", felder=FELDER, log=AGENT.sync_log(15),
                           db=AGENT.db_path, faellig=AGENT.geplanter_sync_faellig())


@app.post("/sprache")
def sprache_wechseln():
    AGENT.sprache_setzen(request.form.get("sprache", "de"))
    if AGENT.vault_ok():
        try:
            AGENT.ensure_basics()
            AGENT.sync("manuell")
        except Exception as exc:
            flash(str(exc), "fehler")
    return redirect(_zurueck("heute"))


@app.errorhandler(404)
def nicht_gefunden(_e):
    return render_template("fehler.html", meldung=_("Seite oder Eintrag nicht gefunden.")), 404


if __name__ == "__main__":
    port = int(AGENT.cfg.get("port", 5055))
    AGENT.starte_scheduler()
    if not os.environ.get("OBSIDIAN_AGENT_NO_BROWSER"):
        threading.Timer(1.2, lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()
    print(f"Obsidian-Agent: http://127.0.0.1:{port}  (Ctrl+C)")
    app.run(host="127.0.0.1", port=port, debug=False)
