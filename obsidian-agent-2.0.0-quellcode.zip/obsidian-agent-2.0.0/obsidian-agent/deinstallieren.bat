@echo off
REM Obsidian-Agent SDM - Deinstallation (Windows). Der Obsidian-Vault bleibt unveraendert.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0deinstallieren.ps1" %*
