﻿# ======================================================================
#  Obsidian-Agent SDM – Deinstallation (Windows)
#  - beendet den laufenden Agent, entfernt die geplanten Aufgaben und den Autostart
#  - sichert config.json und planer.db auf den Desktop
#  - entfernt die Python-Umgebung (.venv) und auf Wunsch den Programmordner
#  Der Obsidian-Vault wird NICHT verändert.
#  -Still: ohne Rückfragen (für das Setup-Programm; der Programmordner bleibt, das Setup löscht ihn)
# ======================================================================
param([string]$Sprache = '', [switch]$Still)
$Dir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Dir

$Codes = @('de','en','fr','it','es','ro')
if (-not $Sprache -and (Test-Path 'config.json')) {
    try { $Sprache = (Get-Content 'config.json' -Raw -Encoding UTF8 | ConvertFrom-Json).sprache } catch {}
}
if ($Codes -notcontains $Sprache) { $Sprache = 'de' }

$T = @{
 de = @{ titel='Obsidian-Agent SDM deinstallieren'; vault='Dein Obsidian-Vault bleibt unverändert.'; weiter='Fortfahren? (j/n)'; beendet='Laufender Agent beendet'; task='Aufgabe entfernt'; lnk='Autostart entfernt'; backup='Sicherung'; venv='Python-Umgebung entfernt'; ordner='Programmordner komplett löschen? (j/n)'; geloescht='Der Programmordner wird nach dem Schliessen dieses Fensters gelöscht.'; fertig='Deinstallation abgeschlossen.'; umzug='Umzug: Programm neu installieren und config.json sowie planer.db aus der Sicherung in den Programmordner kopieren.'; enter='Enter zum Schliessen'; ja='j' }
 en = @{ titel='Uninstall Obsidian-Agent SDM'; vault='Your Obsidian vault stays unchanged.'; weiter='Continue? (y/n)'; beendet='Running agent stopped'; task='Task removed'; lnk='Startup entry removed'; backup='Backup'; venv='Python environment removed'; ordner='Delete the whole program folder? (y/n)'; geloescht='The program folder will be deleted after this window closes.'; fertig='Uninstall complete.'; umzug='Moving: reinstall the program and copy config.json and planer.db from the backup into the program folder.'; enter='Press Enter to close'; ja='y' }
 fr = @{ titel='Désinstaller Obsidian-Agent SDM'; vault='Votre coffre Obsidian reste inchangé.'; weiter='Continuer ? (o/n)'; beendet='Agent en cours arrêté'; task='Tâche supprimée'; lnk='Démarrage automatique supprimé'; backup='Sauvegarde'; venv='Environnement Python supprimé'; ordner='Supprimer tout le dossier du programme ? (o/n)'; geloescht='Le dossier du programme sera supprimé après la fermeture de cette fenêtre.'; fertig='Désinstallation terminée.'; umzug='Déménagement : réinstaller le programme et copier config.json et planer.db depuis la sauvegarde dans le dossier du programme.'; enter='Appuyez sur Entrée pour fermer'; ja='o' }
 it = @{ titel='Disinstallare Obsidian-Agent SDM'; vault='Il tuo vault Obsidian resta invariato.'; weiter='Continuare? (s/n)'; beendet='Agent in esecuzione arrestato'; task='Attività rimossa'; lnk='Avvio automatico rimosso'; backup='Backup'; venv='Ambiente Python rimosso'; ordner='Eliminare l''intera cartella del programma? (s/n)'; geloescht='La cartella del programma verrà eliminata dopo la chiusura di questa finestra.'; fertig='Disinstallazione completata.'; umzug='Trasloco: reinstallare il programma e copiare config.json e planer.db dal backup nella cartella del programma.'; enter='Premere Invio per chiudere'; ja='s' }
 es = @{ titel='Desinstalar Obsidian-Agent SDM'; vault='Su bóveda de Obsidian no se modifica.'; weiter='¿Continuar? (s/n)'; beendet='Agente en ejecución detenido'; task='Tarea eliminada'; lnk='Inicio automático eliminado'; backup='Copia de seguridad'; venv='Entorno de Python eliminado'; ordner='¿Eliminar toda la carpeta del programa? (s/n)'; geloescht='La carpeta del programa se eliminará al cerrar esta ventana.'; fertig='Desinstalación completada.'; umzug='Traslado: reinstale el programa y copie config.json y planer.db de la copia de seguridad a la carpeta del programa.'; enter='Pulse Intro para cerrar'; ja='s' }
 ro = @{ titel='Dezinstalare Obsidian-Agent SDM'; vault='Seiful Obsidian rămâne neschimbat.'; weiter='Continuați? (d/n)'; beendet='Agentul activ a fost oprit'; task='Sarcină eliminată'; lnk='Pornirea automată a fost eliminată'; backup='Copie de rezervă'; venv='Mediul Python a fost eliminat'; ordner='Ștergeți tot folderul programului? (d/n)'; geloescht='Folderul programului va fi șters după închiderea acestei ferestre.'; fertig='Dezinstalare finalizată.'; umzug='Mutare: reinstalați programul și copiați config.json și planer.db din copia de rezervă în folderul programului.'; enter='Apăsați Enter pentru a închide'; ja='d' }
}
$M = $T[$Sprache]
function Ok($m) { Write-Host "[OK] $m" -ForegroundColor Green }
function Ja($frage) { if ($Still) { return $true }; $a = Read-Host $frage; return $a -and ($a.Trim().ToLower().StartsWith($M.ja) -or $a.Trim().ToLower().StartsWith('y')) }

Write-Host ''
Write-Host "=== $($M.titel) ===" -ForegroundColor Cyan
Write-Host $Dir
Write-Host $M.vault
if (-not (Ja $M.weiter)) { exit 0 }

# 1. Laufenden Agent beenden
$Port = 5055
try { $Port = [int]((Get-Content 'config.json' -Raw | ConvertFrom-Json).port) } catch {}
Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue | ForEach-Object {
    Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue; Ok "$($M.beendet) (PID $($_.OwningProcess))" }

# 2. Geplante Aufgaben und Autostart
foreach ($t in @('Obsidian-Agent Weboberflaeche', 'Obsidian-Agent Tages-Sync')) {
    if (Get-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $t -Confirm:$false; Ok "$($M.task): $t" }
}
$Startup = [Environment]::GetFolderPath('Startup')
foreach ($f in @('Obsidian-Agent.lnk', 'Obsidian-Agent.vbs')) {
    $p = Join-Path $Startup $f
    if (Test-Path $p) { Remove-Item $p -Force; Ok $M.lnk }
}
$LogDir = Join-Path $env:LOCALAPPDATA 'obsidian-agent'
if (Test-Path $LogDir) { Remove-Item $LogDir -Recurse -Force -ErrorAction SilentlyContinue }

# 3. Sicherung auf den Desktop
$Backup = Join-Path ([Environment]::GetFolderPath('Desktop')) ("obsidian-agent-backup_" + (Get-Date -Format 'yyyy-MM-dd_HHmm'))
New-Item -ItemType Directory -Force -Path $Backup | Out-Null
foreach ($f in @('config.json', 'planer.db')) { if (Test-Path $f) { Copy-Item $f $Backup -Force } }
Ok "$($M.backup): $Backup"

# 4. Python-Umgebung
foreach ($d in @('.venv', '__pycache__')) { if (Test-Path $d) { Remove-Item $d -Recurse -Force -ErrorAction SilentlyContinue } }
Ok $M.venv

if ($Still) { exit 0 }

# 5. Programmordner
Write-Host ''
if (Ja $M.ordner) {
    Write-Host $M.geloescht
    Read-Host $M.enter | Out-Null
    Set-Location $env:TEMP
    Start-Process cmd -ArgumentList "/c timeout /t 3 /nobreak >nul & rd /s /q `"$Dir`"" -WindowStyle Hidden
    exit 0
}
Write-Host ''
Write-Host $M.fertig
Write-Host $M.umzug
Read-Host $M.enter | Out-Null
