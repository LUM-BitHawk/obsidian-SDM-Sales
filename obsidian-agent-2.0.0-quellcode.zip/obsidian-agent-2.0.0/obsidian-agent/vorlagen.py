"""
Obsidian-Vorlagen für SDM & Vertrieb, in der eingestellten Sprache.

Die Eigenschaften (YAML-Schlüssel) sind in allen Sprachen gleich, damit gemischte Teams
denselben Vault nutzen können. Übersetzt werden nur Überschriften und Hinweise.
Platzhalter {{title}} und {{date}} funktionieren mit dem Obsidian-Kernplugin «Vorlagen»;
die übrigen {{…}} füllt der Agent beim Anlegen aus und lässt sie sonst leer.
"""
from __future__ import annotations

from i18n import t

# Dateiname der Vorlage je Sprache (ohne Sonderzeichen), Präfix für neue Notizen, Ordner-Schlüssel
DATEINAME = {  # de, en, fr, it, es, ro
    "kunde": ("Vorlage_Kunde", "Template_Customer", "Modele_Client", "Modello_Cliente", "Plantilla_Cliente", "Sablon_Client"),
    "kontakt": ("Vorlage_Kontakt", "Template_Contact", "Modele_Contact", "Modello_Contatto", "Plantilla_Contacto", "Sablon_Contact"),
    "asset": ("Vorlage_Asset", "Template_Asset", "Modele_Actif", "Modello_Asset", "Plantilla_Activo", "Sablon_Activ"),
    "opportunity": ("Vorlage_Opportunity", "Template_Opportunity", "Modele_Opportunite", "Modello_Opportunita",
                    "Plantilla_Oportunidad", "Sablon_Oportunitate"),
    "meeting": ("Vorlage_Meeting", "Template_Meeting", "Modele_Reunion", "Modello_Riunione", "Plantilla_Reunion",
                "Sablon_Intalnire"),
    "eskalation": ("Vorlage_Eskalation", "Template_Escalation", "Modele_Escalade", "Modello_Escalation",
                   "Plantilla_Escalado", "Sablon_Escaladare"),
}
SPRACH_INDEX = {"de": 0, "en": 1, "fr": 2, "it": 3, "es": 4, "ro": 5}
PRAEFIX = {  # Dateinamen-Präfix neuer Notizen je Sprache
    "kunde": ("Kunde_", "Customer_", "Client_", "Cliente_", "Cliente_", "Client_"),
    "kontakt": ("Kontakt_", "Contact_", "Contact_", "Contatto_", "Contacto_", "Contact_"),
    "asset": ("Asset_", "Asset_", "Actif_", "Asset_", "Activo_", "Activ_"),
    "opportunity": ("Opp_",) * 6,
    "meeting": ("",) * 6,
    "eskalation": ("Incident_",) * 6,
}
ALLE_PRAEFIXE = sorted({p.rstrip("_") for t in PRAEFIX.values() for p in t if p} | {"LCM", "Opportunity"}, key=len, reverse=True)
TYPEN = {
    "kunde":       {"datei": "Kunde",       "praefix": "Kunde_",  "ordner": "kunden_ordner"},
    "kontakt":     {"datei": "Kontakt",     "praefix": "Kontakt_", "ordner": "kontakte_ordner"},
    "asset":       {"datei": "Asset",       "praefix": "Asset_",  "ordner": "assets_ordner"},
    "opportunity": {"datei": "Opportunity", "praefix": "Opp_",    "ordner": "sales_ordner"},
    "meeting":     {"datei": "Meeting",     "praefix": "",        "ordner": "meetings_ordner"},
    "eskalation":  {"datei": "Eskalation",  "praefix": "Incident_", "ordner": "service_ordner"},
}


def vorlage(typ: str, sprache: str) -> str:
    _ = lambda s: t(sprache, s)  # noqa: E731
    if typ == "kunde":
        return f"""---
typ: kunde
name: {{{{name}}}}
branche: {{{{branche}}}}
sla_level: {{{{sla_level}}}}
status: {{{{status}}}}
vertragsende: {{{{vertragsende}}}}
kuendigungsfrist_monate: {{{{kuendigungsfrist_monate}}}}
jahresumsatz: {{{{jahresumsatz}}}}
sdm_lead: {{{{sdm_lead}}}}
account_manager: {{{{account_manager}}}}
hauptkontakt:
entscheider:
tags: [kunde]
---
# 🏢 {{{{title}}}}

## 📌 {_("Eckdaten & Verträge")}
- **{_("Wichtige Services")}:**
- **{_("Besonderheiten / SLA-Vereinbarungen")}:**

## 🖥️ {_("IT-Landschaft & kritische Lifecycles")}
- {_("Assets verknüpfen sich über die Eigenschaft «kunde» automatisch mit diesem Kunden.")}

## 🚨 {_("Aktuelle Risiken & Eskalationen")}
-

## 💰 {_("Verkaufschancen & Upselling")}
-

## ✅ {_("Aufgaben & Next Steps")}
"""
    if typ == "kontakt":
        return f"""---
typ: kontakt
kunde: "{{{{kunde}}}}"
funktion: {{{{funktion}}}}
rolle: {{{{rolle}}}}
email: {{{{email}}}}
telefon: {{{{telefon}}}}
stimmung: {{{{stimmung}}}}
loeschen_nach: {{{{loeschen_nach}}}}
tags: [kontakt]
---
# 👤 {{{{title}}}}

- **{_("Kunde")}:** {{{{kunde}}}}
- **{_("Funktion")}:** {{{{funktion}}}}

## {_("Geschäftliche Notizen")}
> {_("Nur sachliche, geschäftlich nötige Angaben erfassen (Datenschutz).")}
-

## ✅ {_("Aufgaben & Next Steps")}
"""
    if typ == "asset":
        return f"""---
typ: asset
kunde: "{{{{kunde}}}}"
kategorie: {{{{kategorie}}}}
hersteller: {{{{hersteller}}}}
produkt_version: {{{{produkt_version}}}}
anzahl_units: {{{{anzahl_units}}}}
kauf_start_datum: {{{{kauf_start_datum}}}}
end_of_support: {{{{end_of_support}}}}
end_of_life: {{{{end_of_life}}}}
vertragsende: {{{{vertragsende}}}}
kuendigungsfrist_monate: {{{{kuendigungsfrist_monate}}}}
esu_bis: {{{{esu_bis}}}}
kritikalitaet: {{{{kritikalitaet}}}}
betriebsstatus: {{{{betriebsstatus}}}}
verknuepfte_opportunity:
tags: [asset, lifecycle]
---
# ⚙️ {{{{title}}}}

- **{_("Kunde")}:** {{{{kunde}}}}
- **{_("Produkt & Version")}:** {{{{produkt_version}}}}

## 📅 {_("Lifecycle- & Vertragsdaten")}
- **{_("Wartungsvertrag / Subscription-Nr.")}:**
- {_("Die Phase (Strategie, Angebot, Umsetzung) berechnet der Agent aus den Daten oben.")}

## 🔧 {_("Technische Details & Abhängigkeiten")}
- **{_("Host / Umgebung")}:**
- **{_("Abhängige Applikationen")}:**

## 💰 {_("Vertriebspotenzial & Migrationspfad")}
- **{_("Empfohlene Nachfolgelösung")}:**
- **{_("Geschätztes Volumen")}:**

## ✅ {_("Aufgaben & Next Steps")}
"""
    if typ == "opportunity":
        return f"""---
typ: opportunity
kunde: "{{{{kunde}}}}"
phase: {{{{phase}}}}
wahrscheinlichkeit: {{{{wahrscheinlichkeit}}}}
volumen: {{{{volumen}}}}
abschluss_geplant: {{{{abschluss_geplant}}}}
quelle: {{{{quelle}}}}
verknuepftes_asset: "{{{{verknuepftes_asset}}}}"
tags: [sales, opportunity]
---
# 💰 {{{{title}}}}

- **{_("Kunde")}:** {{{{kunde}}}}
- **{_("Auslöser / Ursprung")}:** {{{{ausloeser}}}}

## 🎯 {_("Kundenproblem / Handlungsbedarf")}
-

## 🛠️ {_("Vorgeschlagene Lösung & Mehrwert")}
-

## ✅ {_("Aufgaben & Next Steps")}
- [ ] {_("Technisches Konzept & Aufwand mit Delivery abstimmen")}
- [ ] {_("Angebot erstellen und versenden")}
"""
    if typ == "meeting":
        return f"""---
typ: meeting
kunde: "{{{{kunde}}}}"
art: {{{{art}}}}
datum: {{{{datum}}}}
teilnehmer: {{{{teilnehmer}}}}
tags: [meeting]
---
# 🤝 {{{{title}}}}
**{_("Kunde")}:** {{{{kunde}}}} · **{_("Datum")}:** {{{{datum}}}}

## 📋 {_("Agenda & Service Delivery Check")}
1. **{_("SLA-Rückblick & Tickets")}:**
2. **{_("Laufende Projekte / Changes")}:**
3. **{_("Offene Eskalationen")}:**
4. **{_("Lifecycle-Check")}:**
{{{{lifecycle}}}}

## 🔁 {_("Offene Aufgaben vor dem Termin")}
{{{{offene_aufgaben}}}}

## 💡 {_("Notizen & Kundenfeedback (Pain Points)")}
-

## 🚀 {_("Erkannte Verkaufschancen")}
-

## ✅ {_("Aufgaben & Next Steps")}
"""
    if typ == "eskalation":
        return f"""---
typ: eskalation
kunde: "{{{{kunde}}}}"
beginn: {{{{date}}}}
prioritaet: {{{{prioritaet}}}}
status: offen
tags: [eskalation]
---
# 🚨 {{{{title}}}}

- **{_("Kunde")}:** {{{{kunde}}}}

## {_("Auswirkung")}
{{{{beschreibung}}}}

## {_("Zeitlinie")}
- {{{{date}}}}

## {_("Ursache")}

## {_("Massnahmen")}

## ✅ {_("Aufgaben & Next Steps")}
"""
    raise KeyError(typ)
