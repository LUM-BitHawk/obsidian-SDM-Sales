﻿# ======================================================================
#  Obsidian-Agent SDM – Einrichtung für Windows
#  Aufruf: installieren.bat [de|en|fr|it|es|ro]
#  Vom Setup-Programm: -Still -Vault <Ordner> [-OhneAutostart]  (ohne Rückfragen, ohne Konsole)
#   1. Python-Umgebung (.venv) und Flask
#   2. Sprache und Vault-Pfad (Ordner-Dialog, falls noch keiner gesetzt ist)
#   3. Aufgabe "Obsidian-Agent Weboberflaeche": Start bei jeder Anmeldung im Hintergrund
#   4. Aufgabe "Obsidian-Agent Tages-Sync": täglicher Sync, verpasste Läufe werden nachgeholt
#  Mehrfach ausführbar, keine Administratorrechte nötig.
# ======================================================================
param([string]$Sprache = '', [switch]$OhnePause, [string]$Vault = '', [switch]$Still, [switch]$OhneAutostart)
if ($Still) { $OhnePause = $true }
$ErrorActionPreference = 'Continue'
$Dir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Dir

$TaskGui  = 'Obsidian-Agent Weboberflaeche'
$TaskSync = 'Obsidian-Agent Tages-Sync'
$Startup  = [Environment]::GetFolderPath('Startup')
$Lnk      = Join-Path $Startup 'Obsidian-Agent.lnk'
$LogFile  = Join-Path $env:LOCALAPPDATA 'obsidian-agent\gui.log'
$VenvPy   = Join-Path $Dir '.venv\Scripts\python.exe'
$VenvPyw  = Join-Path $Dir '.venv\Scripts\pythonw.exe'
$Starter  = Join-Path $Dir 'hintergrund.pyw'

# --- Sprache --------------------------------------------------------------------------
$Codes = @('de','en','fr','it','es','ro')
if (-not $Sprache -and (Test-Path (Join-Path $Dir 'config.json'))) {
    try { $Sprache = (Get-Content (Join-Path $Dir 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json).sprache } catch {}
}
if (-not $Sprache) { $Sprache = (Get-Culture).TwoLetterISOLanguageName }
if ($Codes -notcontains $Sprache) { $Sprache = 'de' }

$T = @{
 de = @{ titel='Obsidian-Agent SDM – Einrichtung (Windows)'; ordner='Programmordner'; nopy='Python 3.10 oder neuer wurde nicht gefunden. Bitte installieren (Häkchen «Add python.exe to PATH») und die Einrichtung erneut starten.'; venv='Python-Umgebung wird eingerichtet'; venvfail='Python-Umgebung (.venv) konnte nicht angelegt werden.'; pipfail='Installation von Flask fehlgeschlagen (Internet oder Proxy prüfen).'; pyok='Python-Umgebung bereit'; vaultwahl='Bitte im Dialog den Obsidian-Vault-Ordner wählen (ggf. hinter diesem Fenster).'; vaultdlg='Obsidian-Vault-Ordner wählen'; novault='Kein Vault gewählt – der Pfad kann später unter Einstellungen gesetzt werden.'; guiok='Aufgabe eingerichtet: Start bei jeder Anmeldung'; nosched='Aufgabenplanung nicht erlaubt'; lnkok='Stattdessen Autostart-Verknüpfung angelegt'; syncok='Täglicher Sync eingerichtet um'; syncfail='Täglicher Sync konnte nicht eingerichtet werden'; syncwarn='Die Tagesübersicht wird dann nur aktualisiert, solange die Weboberfläche läuft.'; laeuft='Agent wird neu gestartet'; start='Agent wird im Hintergrund gestartet'; fertig='Fertig! Weboberfläche'; auto='Sie startet ab jetzt nach jeder Anmeldung automatisch im Hintergrund.'; keinport='Der Agent antwortet nicht auf Port'; log='Protokoll'; enter='Enter zum Schliessen'; fehler='FEHLER' }
 en = @{ titel='Obsidian-Agent SDM – Setup (Windows)'; ordner='Program folder'; nopy='Python 3.10 or newer was not found. Please install it (tick «Add python.exe to PATH») and run the setup again.'; venv='Setting up the Python environment'; venvfail='The Python environment (.venv) could not be created.'; pipfail='Installing Flask failed (check internet or proxy).'; pyok='Python environment ready'; vaultwahl='Please select your Obsidian vault folder in the dialog (it may be behind this window).'; vaultdlg='Select your Obsidian vault folder'; novault='No vault selected – you can set the path later in the settings.'; guiok='Task created: start at every sign-in'; nosched='Task Scheduler not allowed'; lnkok='Startup shortcut created instead'; syncok='Daily sync set up at'; syncfail='The daily sync could not be set up'; syncwarn='The cockpit is then only refreshed while the web interface is running.'; laeuft='Restarting the agent'; start='Starting the agent in the background'; fertig='Done! Web interface'; auto='From now on it starts automatically in the background at every sign-in.'; keinport='The agent does not respond on port'; log='Log'; enter='Press Enter to close'; fehler='ERROR' }
 fr = @{ titel='Obsidian-Agent SDM – Installation (Windows)'; ordner='Dossier du programme'; nopy='Python 3.10 ou plus récent est introuvable. Veuillez l''installer (cocher «Add python.exe to PATH») puis relancer l''installation.'; venv='Préparation de l''environnement Python'; venvfail='L''environnement Python (.venv) n''a pas pu être créé.'; pipfail='L''installation de Flask a échoué (vérifier Internet ou le proxy).'; pyok='Environnement Python prêt'; vaultwahl='Veuillez choisir le dossier de votre coffre Obsidian dans la boîte de dialogue (éventuellement derrière cette fenêtre).'; vaultdlg='Choisir le dossier du coffre Obsidian'; novault='Aucun coffre choisi – le chemin peut être défini plus tard dans les paramètres.'; guiok='Tâche créée : démarrage à chaque ouverture de session'; nosched='Planificateur de tâches non autorisé'; lnkok='Raccourci de démarrage créé à la place'; syncok='Synchronisation quotidienne planifiée à'; syncfail='La synchronisation quotidienne n''a pas pu être planifiée'; syncwarn='Le cockpit n''est alors actualisé que lorsque l''interface web fonctionne.'; laeuft='Redémarrage de l''agent'; start='Démarrage de l''agent en arrière-plan'; fertig='Terminé ! Interface web'; auto='Elle démarre désormais automatiquement en arrière-plan à chaque ouverture de session.'; keinport='L''agent ne répond pas sur le port'; log='Journal'; enter='Appuyez sur Entrée pour fermer'; fehler='ERREUR' }
 it = @{ titel='Obsidian-Agent SDM – Installazione (Windows)'; ordner='Cartella del programma'; nopy='Python 3.10 o successivo non trovato. Installarlo (spuntare «Add python.exe to PATH») e riavviare l''installazione.'; venv='Preparazione dell''ambiente Python'; venvfail='Impossibile creare l''ambiente Python (.venv).'; pipfail='Installazione di Flask non riuscita (verificare Internet o proxy).'; pyok='Ambiente Python pronto'; vaultwahl='Selezionare la cartella del vault Obsidian nella finestra di dialogo (forse dietro questa finestra).'; vaultdlg='Selezionare la cartella del vault Obsidian'; novault='Nessun vault selezionato – il percorso si può impostare più tardi nelle impostazioni.'; guiok='Attività creata: avvio a ogni accesso'; nosched='Utilità di pianificazione non consentita'; lnkok='Creato invece un collegamento di avvio automatico'; syncok='Sincronizzazione giornaliera impostata alle'; syncfail='Impossibile impostare la sincronizzazione giornaliera'; syncwarn='Il cockpit viene aggiornato solo mentre l''interfaccia web è attiva.'; laeuft='Riavvio dell''agent'; start='Avvio dell''agent in background'; fertig='Fatto! Interfaccia web'; auto='D''ora in poi si avvia automaticamente in background a ogni accesso.'; keinport='L''agent non risponde sulla porta'; log='Registro'; enter='Premere Invio per chiudere'; fehler='ERRORE' }
 es = @{ titel='Obsidian-Agent SDM – Instalación (Windows)'; ordner='Carpeta del programa'; nopy='No se encontró Python 3.10 o superior. Instálelo (marque «Add python.exe to PATH») y vuelva a iniciar la instalación.'; venv='Preparando el entorno de Python'; venvfail='No se pudo crear el entorno de Python (.venv).'; pipfail='La instalación de Flask ha fallado (compruebe Internet o el proxy).'; pyok='Entorno de Python listo'; vaultwahl='Seleccione la carpeta de su bóveda de Obsidian en el cuadro de diálogo (puede estar detrás de esta ventana).'; vaultdlg='Seleccione la carpeta de la bóveda de Obsidian'; novault='No se seleccionó ninguna bóveda; puede configurar la ruta más tarde en los ajustes.'; guiok='Tarea creada: inicio en cada inicio de sesión'; nosched='El Programador de tareas no está permitido'; lnkok='Se creó en su lugar un acceso directo de inicio'; syncok='Sincronización diaria programada a las'; syncfail='No se pudo programar la sincronización diaria'; syncwarn='El cockpit solo se actualiza mientras la interfaz web esté en ejecución.'; laeuft='Reiniciando el agente'; start='Iniciando el agente en segundo plano'; fertig='¡Listo! Interfaz web'; auto='A partir de ahora se inicia automáticamente en segundo plano en cada inicio de sesión.'; keinport='El agente no responde en el puerto'; log='Registro'; enter='Pulse Intro para cerrar'; fehler='ERROR' }
 ro = @{ titel='Obsidian-Agent SDM – Instalare (Windows)'; ordner='Folderul programului'; nopy='Python 3.10 sau mai nou nu a fost găsit. Instalați-l (bifați «Add python.exe to PATH») și reporniți instalarea.'; venv='Se pregătește mediul Python'; venvfail='Mediul Python (.venv) nu a putut fi creat.'; pipfail='Instalarea Flask a eșuat (verificați internetul sau proxy-ul).'; pyok='Mediul Python este pregătit'; vaultwahl='Selectați folderul seifului Obsidian în fereastra de dialog (poate fi în spatele acestei ferestre).'; vaultdlg='Selectați folderul seifului Obsidian'; novault='Niciun seif selectat – calea poate fi setată ulterior în setări.'; guiok='Sarcină creată: pornire la fiecare autentificare'; nosched='Planificatorul de activități nu este permis'; lnkok='S-a creat în schimb o scurtătură de pornire'; syncok='Sincronizare zilnică programată la'; syncfail='Sincronizarea zilnică nu a putut fi programată'; syncwarn='Cockpitul se actualizează doar cât timp interfața web rulează.'; laeuft='Se repornește agentul'; start='Se pornește agentul în fundal'; fertig='Gata! Interfața web'; auto='De acum pornește automat în fundal la fiecare autentificare.'; keinport='Agentul nu răspunde pe portul'; log='Jurnal'; enter='Apăsați Enter pentru a închide'; fehler='EROARE' }
}
$M = $T[$Sprache]

function Ok($m)   { Write-Host "[OK] $m" -ForegroundColor Green }
function Warn($m) { Write-Host "[!!] $m" -ForegroundColor Yellow }
function Info($m) { Write-Host "...  $m" }
function Pause-Ende { if (-not $OhnePause) { Read-Host $M.enter | Out-Null } }
function Fail($m, $code = 1) { Write-Host "[$($M.fehler)] $m" -ForegroundColor Red; Pause-Ende; exit $code }
function Lauscht($p) { [bool](Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue) }

Write-Host ''
Write-Host "=== $($M.titel) ===" -ForegroundColor Cyan
Write-Host "$($M.ordner): $Dir"
Write-Host ''

# --- 1. Python ------------------------------------------------------------------------
if (-not (Test-Path $VenvPy)) {
    $py = $null
    foreach ($kandidat in @('py -3', 'python')) {
        $teile = $kandidat.Split(' ')
        $exe = $teile[0]; $arg = @($teile | Select-Object -Skip 1)
        if (-not (Get-Command $exe -ErrorAction SilentlyContinue)) { continue }
        $v = & $exe @arg -c 'import sys; print(sys.version_info >= (3, 10))' 2>$null
        if ($v -eq 'True') { $py = @{ exe = $exe; arg = $arg }; break }
    }
    if (-not $py) {
        if (-not $Still) { Start-Process 'https://www.python.org/downloads/windows/' }
        Fail $M.nopy 2
    }
    Info $M.venv
    & $py.exe @($py.arg) -m venv .venv
    if (-not (Test-Path $VenvPy)) { Fail $M.venvfail }
}
& $VenvPy -m pip install -q --upgrade pip 2>$null | Out-Null
& $VenvPy -m pip install -q -r requirements.txt
if ($LASTEXITCODE -ne 0) { Fail $M.pipfail 3 }
Ok "$($M.pyok) ($(& $VenvPy --version))"

# --- 2. Sprache und Vault ----------------------------------------------------------------
& $VenvPy agent.py sprache $Sprache | Out-Null
if ($Vault -and (Test-Path -LiteralPath $Vault -PathType Container)) {
    & $VenvPy -c "import agent, sys; c = agent.load_config(); c['vault_path'] = sys.argv[1]; agent.save_config(c)" $Vault
    & $VenvPy agent.py sprache $Sprache | Out-Null
}
$vaultOk = & $VenvPy -c "import agent, os; c = agent.load_config(); print(os.path.isdir(os.path.expanduser(c['vault_path'])))"
if ($vaultOk -ne 'True' -and $Still) {
    Warn $M.novault
} elseif ($vaultOk -ne 'True') {
    Info $M.vaultwahl
    Add-Type -AssemblyName System.Windows.Forms
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = $M.vaultdlg
    $dlg.ShowNewFolderButton = $true
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        & $VenvPy -c "import agent, sys; c = agent.load_config(); c['vault_path'] = sys.argv[1]; agent.save_config(c)" $dlg.SelectedPath
        & $VenvPy agent.py sprache $Sprache | Out-Null
        Ok "Vault: $($dlg.SelectedPath)"
    } else {
        Warn $M.novault
    }
} else {
    Ok "Vault: $(& $VenvPy -c "import agent; print(agent.load_config()['vault_path'])")"
}
& $VenvPy agent.py sync

$Port     = [int](& $VenvPy -c "import agent; print(agent.load_config().get('port', 5055))")
$SyncZeit = (& $VenvPy -c "import agent; print(agent.load_config().get('sync_zeit', '04:00'))")

# --- 3. Geplante Aufgaben -------------------------------------------------------------------
$User = "$env:USERDOMAIN\$env:USERNAME"
$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
    -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) `
    -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
$Principal = New-ScheduledTaskPrincipal -UserId $User -LogonType Interactive -RunLevel Limited

$guiArt = $null
if ($OhneAutostart) {
    if (Get-ScheduledTask -TaskName $TaskGui -ErrorAction SilentlyContinue) { Unregister-ScheduledTask -TaskName $TaskGui -Confirm:$false }
    if (Test-Path $Lnk) { Remove-Item $Lnk -Force }
    $guiArt = 'aus'
} else { try {
    $act = New-ScheduledTaskAction -Execute $VenvPyw -Argument "`"$Starter`"" -WorkingDirectory $Dir
    $trg = New-ScheduledTaskTrigger -AtLogOn -User $User
    Register-ScheduledTask -TaskName $TaskGui -Action $act -Trigger $trg -Settings $Settings `
        -Principal $Principal -Description 'Obsidian-Agent SDM' -Force -ErrorAction Stop | Out-Null
    if (Test-Path $Lnk) { Remove-Item $Lnk -Force }
    $guiArt = 'task'
    Ok "$($M.guiok) ('$TaskGui')"
} catch {
    $ws = New-Object -ComObject WScript.Shell
    $s = $ws.CreateShortcut($Lnk)
    $s.TargetPath = $VenvPyw
    $s.Arguments = "`"$Starter`""
    $s.WorkingDirectory = $Dir
    $s.Description = 'Obsidian-Agent SDM'
    $s.Save()
    $guiArt = 'lnk'
    Warn "$($M.nosched) ($($_.Exception.Message.Trim()))"
    Ok "$($M.lnkok): $Lnk"
} }

try {
    $h, $m = $SyncZeit.Split(':')
    $act = New-ScheduledTaskAction -Execute $VenvPyw -Argument "`"$Dir\agent.py`" sync --geplant" -WorkingDirectory $Dir
    $trg = New-ScheduledTaskTrigger -Daily -At ([datetime]::Today.AddHours([int]$h).AddMinutes([int]$m))
    Register-ScheduledTask -TaskName $TaskSync -Action $act -Trigger $trg -Settings $Settings `
        -Principal $Principal -Description 'Obsidian-Agent SDM – Sync' -Force -ErrorAction Stop | Out-Null
    Ok "$($M.syncok) $SyncZeit"
} catch {
    Warn "$($M.syncfail): $($_.Exception.Message.Trim())"
    Warn $M.syncwarn
}

# --- 4. Starten (bei Update: neu starten, damit der neue Programmstand geladen wird) -----------
if (Lauscht $Port) {
    Info $M.laeuft
    if ($guiArt -eq 'task') { Stop-ScheduledTask -TaskName $TaskGui -ErrorAction SilentlyContinue }
    Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue |
        ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Seconds 1
}
if ($Still -and $guiArt -eq 'aus') { Ok $M.pyok; exit 0 }  # Setup startet den Agent auf der letzten Seite
Info $M.start
if ($guiArt -eq 'task') { Start-ScheduledTask -TaskName $TaskGui }
else { Start-Process -FilePath $VenvPyw -ArgumentList "`"$Starter`"" -WorkingDirectory $Dir }
for ($i = 0; $i -lt 20 -and -not (Lauscht $Port); $i++) { Start-Sleep -Milliseconds 500 }

Write-Host ''
if ($Still) { if (Lauscht $Port) { Ok "$($M.fertig): http://127.0.0.1:$Port" }; exit 0 }
if (Lauscht $Port) {
    Ok "$($M.fertig): http://127.0.0.1:$Port"
    Write-Host "     $($M.auto)"
    Start-Process "http://127.0.0.1:$Port"
} else {
    Warn "$($M.keinport) $Port."
    if (Test-Path $LogFile) { Get-Content $LogFile -Tail 8 }
    Write-Host "     $($M.log): $LogFile"
}
Write-Host ''
Pause-Ende
