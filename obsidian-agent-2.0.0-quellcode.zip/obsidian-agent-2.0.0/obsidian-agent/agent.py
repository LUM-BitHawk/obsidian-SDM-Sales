"""
Obsidian-Agent für Service Delivery Management & Vertrieb – Kernlogik
=====================================================================
Die Markdown-Dateien im Obsidian-Vault sind die einzige Wahrheit. Die SQLite-Datenbank
(planer.db) ist nur Index: Sie wird bei jedem Sync aus dem Vault neu aufgebaut.

Objekte (Eigenschaft «typ» im Frontmatter):
  kunde · kontakt · asset (früher «lcm») · opportunity · meeting · eskalation
Aufgaben sind normale Checkbox-Zeilen in beliebigen Notizen, kompatibel mit dem
Obsidian-Plugin «Tasks»:  - [ ] Angebot senden 📅 2026-12-01

CLI:
  python agent.py sync               # Vault einlesen, Heute.md schreiben
  python agent.py sync --geplant     # wie oben, zählt als geplanter Tageslauf
  python agent.py heute              # fällige Aufgaben in der Konsole
  python agent.py sprache fr         # Sprache setzen (de, en, fr, it, es, ro)
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import sqlite3
import sys
import threading
import time
import urllib.parse
from pathlib import Path

import i18n
import vorlagen

BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "config.json"

ORDNER_KEYS = ["planer_ordner", "kunden_ordner", "kontakte_ordner", "meetings_ordner",
               "service_ordner", "sales_ordner", "assets_ordner", "vorlagen_ordner"]

ORDNER_STANDARD = {
    "planer_ordner":   {l: "00_Cockpit" for l in i18n.SPRACHEN},
    "kunden_ordner":   {"de": "01_Kunden", "en": "01_Customers", "fr": "01_Clients", "it": "01_Clienti",
                        "es": "01_Clientes", "ro": "01_Clienti"},
    "kontakte_ordner": {"de": "02_Kontakte", "en": "02_Contacts", "fr": "02_Contacts", "it": "02_Contatti",
                        "es": "02_Contactos", "ro": "02_Contacte"},
    "meetings_ordner": {"de": "03_Meetings", "en": "03_Meetings", "fr": "03_Reunions", "it": "03_Riunioni",
                        "es": "03_Reuniones", "ro": "03_Intalniri"},
    "service_ordner":  {"de": "04_Service_Eskalationen", "en": "04_Service_Escalations",
                        "fr": "04_Service_Escalades", "it": "04_Service_Escalation",
                        "es": "04_Servicio_Escalados", "ro": "04_Service_Escaladari"},
    "sales_ordner":    {"de": "05_Sales_Chancen", "en": "05_Sales_Opportunities", "fr": "05_Ventes_Opportunites",
                        "it": "05_Vendite_Opportunita", "es": "05_Ventas_Oportunidades",
                        "ro": "05_Vanzari_Oportunitati"},
    "assets_ordner":   {"de": "06_IT_Assets_Lifecycle", "en": "06_IT_Assets_Lifecycle",
                        "fr": "06_Actifs_IT_Cycle_de_vie", "it": "06_Asset_IT_Ciclo_di_vita",
                        "es": "06_Activos_TI_Ciclo_de_vida", "ro": "06_Active_IT_Ciclu_de_viata"},
    "vorlagen_ordner": {"de": "99_Vorlagen", "en": "99_Templates", "fr": "99_Modeles", "it": "99_Modelli",
                        "es": "99_Plantillas", "ro": "99_Sabloane"},
}

DEFAULT_CONFIG = {
    "sprache": "de",
    "vault_path": str(Path.home() / "Documents" / "Obsidian"),
    "db_path": "planer.db",
    **{k: v["de"] for k, v in ORDNER_STANDARD.items()},
    "waehrung": "CHF",
    "sync_zeit": "04:00",
    "demnaechst_tage": 7,
    "port": 5055,
}

# --- Wertelisten (gespeichert werden immer die Codes links) -----------------------
SLA_STUFEN = ["gold", "silber", "bronze"]
KUNDEN_STATUS = ["gruen", "gelb", "rot"]
ASSET_KATEGORIEN = ["hardware", "netzwerk", "betriebssystem", "applikation", "lizenz", "vertrag", "zertifikat"]
BETRIEBSSTATUS = ["planung", "betrieb", "auslauf", "ausser_betrieb"]
KRITIKALITAET = ["hoch", "mittel", "niedrig"]
OPP_PHASEN = ["qualifizierung", "angebot", "verhandlung", "gewonnen", "verloren"]
OPP_WKEIT = {"qualifizierung": 20, "angebot": 50, "verhandlung": 75, "gewonnen": 100, "verloren": 0}
QUELLEN = ["lifecycle", "service", "bestandskunde", "neukunde"]
MEETING_ARTEN = ["jour_fixe", "service_review", "qbr", "call", "workshop"]
KONTAKT_ROLLEN = ["entscheider", "einfluss", "anwender", "einkauf"]
STIMMUNGEN = ["positiv", "neutral", "kritisch"]
ESK_PRIO = ["p1", "p2", "p3"]

# Anzeige-Texte (deutsch = Übersetzungsschlüssel)
LABEL = {
    "gold": "Gold", "silber": "Silber", "bronze": "Bronze",
    "gruen": "grün", "gelb": "gelb", "rot": "rot",
    "hardware": "Hardware", "netzwerk": "Netzwerk", "betriebssystem": "Betriebssystem",
    "applikation": "Applikation / Datenbank", "lizenz": "Lizenz / Cloud", "vertrag": "Vertrag / Wartung",
    "zertifikat": "Zertifikat",
    "planung": "Planung", "betrieb": "Betrieb", "auslauf": "Auslauf", "ausser_betrieb": "Ausser Betrieb",
    "hoch": "hoch", "mittel": "mittel", "niedrig": "niedrig",
    "qualifizierung": "Qualifizierung", "angebot": "Angebot", "verhandlung": "Verhandlung",
    "gewonnen": "Gewonnen", "verloren": "Verloren",
    "lifecycle": "Lifecycle", "service": "Service Delivery", "bestandskunde": "Bestandskunde",
    "neukunde": "Neukunde",
    "jour_fixe": "Jour Fixe", "service_review": "Service Review", "qbr": "Quartals-Review (QBR)",
    "call": "Call", "workshop": "Workshop",
    "entscheider": "Wirtschaftlicher Entscheider", "einfluss": "Technischer Einflussnehmer",
    "anwender": "Anwender", "einkauf": "Einkauf",
    "positiv": "positiv", "neutral": "neutral", "kritisch": "kritisch",
    "p1": "P1 – kritisch", "p2": "P2 – hoch", "p3": "P3 – normal",
}

# Freie Schreibweisen (alle Sprachen, Konzept-Altwerte) -> Code
_ALIAS = {
    "grün": "gruen", "green": "gruen", "vert": "gruen", "verde": "gruen",
    "yellow": "gelb", "jaune": "gelb", "giallo": "gelb", "amarillo": "gelb", "galben": "gelb",
    "red": "rot", "rouge": "rot", "rosso": "rot", "rojo": "rot", "roșu": "rot", "rosu": "rot",
    "silver": "silber", "argent": "silber", "argento": "silber", "plata": "silber", "argint": "silber",
    "or": "gold", "oro": "gold", "aur": "gold",
    "qualification": "qualifizierung", "qualifica": "qualifizierung", "calificación": "qualifizierung",
    "calificacion": "qualifizierung", "calificare": "qualifizierung",
    "proposal": "angebot", "offre": "angebot", "offerta": "angebot", "oferta": "angebot",
    "negotiation": "verhandlung", "négociation": "verhandlung", "negociation": "verhandlung",
    "trattativa": "verhandlung", "negociación": "verhandlung", "negociacion": "verhandlung",
    "negociere": "verhandlung",
    "won": "gewonnen", "gagné": "gewonnen", "gagne": "gewonnen", "vinto": "gewonnen", "ganado": "gewonnen",
    "câștigat": "gewonnen", "castigat": "gewonnen",
    "lost": "verloren", "perdu": "verloren", "perso": "verloren", "perdido": "verloren", "pierdut": "verloren",
    "lifecycle-management": "lifecycle", "lifecycle management": "lifecycle",
    "service delivery": "service", "kaltakquise": "neukunde", "new customer": "neukunde",
    "existing customer": "bestandskunde",
    "betriebssysteme": "betriebssystem", "os": "betriebssystem", "network": "netzwerk",
    "application": "applikation", "software": "applikation", "datenbank": "applikation",
    "license": "lizenz", "licence": "lizenz", "service": "vertrag", "contract": "vertrag",
    "certificate": "zertifikat", "aktiv": "betrieb", "active": "betrieb", "beschaffung": "planung",
    "ausser betrieb": "ausser_betrieb", "decommissioned": "ausser_betrieb",
    "jour fixe": "jour_fixe", "service review": "service_review",
}


def code(wert, erlaubt: list[str], standard: str = "") -> str:
    """Freie Eingabe (z.B. «Grün», «Lifecycle-Management», «Won») auf einen Code abbilden."""
    w = str(wert or "").strip().lower()
    if not w:
        return standard
    if w.replace(" ", "_") in erlaubt:
        return w.replace(" ", "_")
    w = _ALIAS.get(w, w).replace(" ", "_")
    if w in erlaubt:
        return w
    for e in erlaubt:  # «Qualifizierung (Lead)» o.ä.
        if w.startswith(e):
            return e
    for k, v in _ALIAS.items():
        if w.startswith(k.replace(" ", "_")) and v in erlaubt:
            return v
    return standard


# ---------------------------------------------------------------------------
# Hilfsfunktionen
# ---------------------------------------------------------------------------
FM_RE = re.compile(r"\A---[ \t]*\r?\n(.*?)^---[ \t]*(?:\r?\n|\Z)", re.S | re.M)
TASK_RE = re.compile(r"^(\s*[-*+] \[)([ xX])(\] )(.*)$")
FAELLIG_RE = re.compile(r"📅\s*(\d{4}-\d{2}-\d{2})")
ERLEDIGT_RE = re.compile(r"\s*✅\s*\d{4}-\d{2}-\d{2}")
EMOJI_META_RE = re.compile(r"\s*(?:[📅⏳🛫✅➕❌]\s*\d{4}-\d{2}-\d{2}|[⏫🔼🔽🔺⏬]|🔁[^📅⏳🛫✅]*)")
LINK_RE = re.compile(r"\[\[([^\]|#]+)(?:#[^\]|]*)?(?:\|([^\]]+))?\]\]")


def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    if CONFIG_FILE.exists():
        try:
            cfg.update(json.loads(CONFIG_FILE.read_text(encoding="utf-8")))
        except json.JSONDecodeError:
            pass
    else:
        save_config(cfg)
    cfg["sprache"] = i18n.norm_sprache(cfg.get("sprache"))
    return cfg


def save_config(cfg: dict) -> None:
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")


def safe_name(name: str, underscore: bool = False) -> str:
    name = re.sub(r'[\\/:*?"<>|#^\[\]]', "", str(name)).strip().strip(".")
    name = re.sub(r"\s+", "_" if underscore else " ", name)
    return name[:120]


def _wert(v: str) -> str:
    """Einzelwert aus YAML: Anführungszeichen entfernen, Inline-Kommentar abschneiden."""
    v = v.strip()
    if v and v[0] in "\"'":
        q = v[0]
        ende = v.find(q, 1)
        return v[1:ende] if ende > 0 else v[1:]
    return re.split(r"\s+#", v, maxsplit=1)[0].strip()


def parse_frontmatter(text: str) -> tuple[dict, str]:
    """Einfacher, robuster YAML-Leser für Obsidian-Properties (flach, Listen als Komma-Text)."""
    m = FM_RE.match(text)
    if not m:
        return {}, text
    data: dict[str, str] = {}
    key = None
    for line in m.group(1).splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if line[0] in " \t-":
            s = line.strip()
            if key and s.startswith("- "):  # Blockliste
                eintrag = _wert(s[2:])
                data[key] = f"{data[key]}, {eintrag}" if data.get(key) else eintrag
            continue
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        key = k.strip().lower()
        v = _wert(v)
        if v.startswith("[") and v.endswith("]") and not v.startswith("[["):
            v = ", ".join(_wert(x) for x in v[1:-1].split(",") if x.strip())
        data[key] = v
    return data, text[m.end():]


def fm_value(v) -> str:
    v = "" if v is None else str(v)
    if v.startswith("[["):
        return json.dumps(v, ensure_ascii=False)
    if re.search(r"[:#]\s|^[\[{&*!|>%@`\"']", v) and not re.match(r"^\[.*\]$", v):
        return json.dumps(v, ensure_ascii=False)
    return v


def set_frontmatter(text: str, values: dict) -> str:
    m = FM_RE.match(text)
    if not m:
        block = [f"{k}: {fm_value(v)}" for k, v in values.items()]
        return "---\n" + "\n".join(block) + "\n---\n" + text
    block = m.group(1).rstrip("\r\n").split("\n") if m.group(1).strip() else []
    for k, v in values.items():
        line = f"{k}: {fm_value(v)}"
        for i, existing in enumerate(block):
            if re.match(rf"^{re.escape(k)}\s*:", existing, re.I):
                block[i] = line
                break
        else:
            block.append(line)
    return "---\n" + "\n".join(block) + "\n---\n" + text[m.end():]


def parse_date(v) -> dt.date | None:
    if not v:
        return None
    if isinstance(v, dt.date):
        return v
    s = str(v).strip().strip("[]\"' ")
    if not s:
        return None
    try:
        return dt.date.fromisoformat(s[:10])
    except ValueError:
        pass
    for fmt in ("%d.%m.%Y", "%d.%m.%y", "%Y/%m/%d", "%d/%m/%Y"):
        try:
            return dt.datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


def iso(d: dt.date | None) -> str:
    return d.isoformat() if d else ""


def zahl_wert(v) -> float:
    s = re.sub(r"[^\d,.\-]", "", str(v or ""))
    if not s:
        return 0.0
    if "," in s and "." in s:
        s = s.replace(",", "") if s.rfind(".") > s.rfind(",") else s.replace(".", "").replace(",", ".")
    elif "," in s:
        s = s.replace(",", ".") if len(s.split(",")[-1]) <= 2 else s.replace(",", "")
    elif s.count(".") > 1 or (s.count(".") == 1 and len(s.split(".")[-1]) == 3):
        s = s.replace(".", "")
    try:
        return float(s)
    except ValueError:
        return 0.0


def link_name(v) -> str:
    """'[[01_Kunden/Kunde_Muster_AG|Muster AG]]' -> 'Kunde_Muster_AG'; 'Muster AG' -> 'Muster AG'."""
    s = str(v or "").strip().strip('"')
    m = LINK_RE.search(s)
    if m:
        s = m.group(1)
    return s.strip().rsplit("/", 1)[-1].removesuffix(".md")


def _minus_monate(d: dt.date, monate: int) -> dt.date:
    j, m = divmod(d.month - 1 - monate, 12)
    jahr, monat = d.year + j, m + 1
    for tag in (d.day, 30, 29, 28):
        try:
            return dt.date(jahr, monat, tag)
        except ValueError:
            continue
    return d


# ---------------------------------------------------------------------------
# Lifecycle-Phase (Konzept: 12 / 6 / 3 Monate vor dem Handlungstermin)
# ---------------------------------------------------------------------------
PHASE_GRENZEN = (("umsetzung", 91), ("angebot", 183), ("strategie", 366))


def lc_phase(a: dict, heute: dt.date) -> dict:
    """Handlungstermin = frühestes von End of Support / End of Life und (Vertragsende − Kündigungsfrist)."""
    if code(a.get("betriebsstatus"), BETRIEBSSTATUS) == "ausser_betrieb":
        return {"klasse": "inaktiv", "tage": None, "frist": None, "ende": None, "frist_verpasst": False}
    try:
        frist_m = int(zahl_wert(a.get("kuendigungsfrist_monate")))
    except ValueError:
        frist_m = 0
    hart = [d for d in (parse_date(a.get("end_of_support")), parse_date(a.get("end_of_life"))) if d]
    vertrag = parse_date(a.get("vertragsende") or a.get("eol_vertragsende"))
    enden = hart + ([vertrag] if vertrag else [])
    if not enden:
        return {"klasse": "unbekannt", "tage": None, "frist": None, "ende": None, "frist_verpasst": False}
    ende = min(enden)
    termine = hart + ([_minus_monate(vertrag, frist_m)] if vertrag else [])
    frist = min(termine)
    tage = (frist - heute).days
    esu = parse_date(a.get("esu_bis"))
    r = {"tage": tage, "frist": frist, "ende": ende, "frist_verpasst": False, "esu": None}
    if ende < heute:
        r["klasse"] = "abgelaufen"
        if esu and esu >= heute:
            r["esu"] = esu
    elif tage < 0:
        r.update(klasse="abgelaufen", frist_verpasst=True)
    else:
        r["klasse"] = next((k for k, g in PHASE_GRENZEN if tage < g), "ok")
    # geschäftskritische Assets eine Stufe früher
    if code(a.get("kritikalitaet"), KRITIKALITAET) == "hoch" and r["klasse"] in ("angebot", "strategie"):
        r["klasse"] = {"angebot": "umsetzung", "strategie": "angebot"}[r["klasse"]]
    return r


PHASE_RANG = {"abgelaufen": 0, "umsetzung": 1, "angebot": 2, "strategie": 3, "ok": 4, "unbekannt": 5, "inaktiv": 6}

# ---------------------------------------------------------------------------
# Datenbank
# ---------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS notizen (
    pfad TEXT PRIMARY KEY, titel TEXT, typ TEXT, kunde TEXT,
    geaendert TEXT, inhalt TEXT, meta TEXT
);
CREATE TABLE IF NOT EXISTS aufgaben (
    pfad TEXT, zeile INTEGER, text TEXT, roh TEXT, faellig TEXT, erledigt INTEGER,
    kunde TEXT, PRIMARY KEY (pfad, zeile)
);
CREATE TABLE IF NOT EXISTS sync_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    zeitpunkt TEXT, art TEXT, dateien INTEGER, aufgaben_offen INTEGER,
    aufgaben_faellig INTEGER, assets INTEGER, dauer_ms INTEGER, fehler TEXT
);
CREATE INDEX IF NOT EXISTS ix_notizen_typ ON notizen(typ);
CREATE INDEX IF NOT EXISTS ix_aufgaben_kunde ON aufgaben(kunde);
"""
TYP_ALIAS = {"lcm": "asset", "customer": "kunde", "contact": "kontakt", "incident": "eskalation",
             "stoerung": "eskalation", "jourfixe": "meeting", "opp": "opportunity"}


class Agent:
    def __init__(self, cfg: dict | None = None):
        self.cfg = cfg or load_config()
        self._lock = threading.Lock()
        self._init_db()

    # --- Sprache -------------------------------------------------------------
    @property
    def sprache(self) -> str:
        return i18n.norm_sprache(self.cfg.get("sprache"))

    def _(self, text: str, **kw) -> str:
        return i18n.t(self.sprache, text, **kw)

    def label(self, c: str) -> str:
        return self._(LABEL.get(c, c)) if c else ""

    def dmy(self, v) -> str:
        d = parse_date(v)
        return d.strftime(i18n.DATUM_FORMAT[self.sprache]) if d else ""

    def sprache_setzen(self, neu: str) -> None:
        """Sprache wechseln. Ordnernamen werden nur angepasst, solange es den Ordner im Vault
        noch nicht gibt und der bisherige Name ein Standardname war (nichts wird umbenannt)."""
        neu = i18n.norm_sprache(neu)
        for key, je_sprache in ORDNER_STANDARD.items():
            alt = self.cfg.get(key) or ""
            if alt not in je_sprache.values():
                continue  # eigener Ordnername: nie ändern
            if self.vault_ok() and (self.vault / alt).is_dir():
                continue  # Ordner existiert bereits
            vorhanden = [n for n in je_sprache.values() if self.vault_ok() and (self.vault / n).is_dir()]
            self.cfg[key] = vorhanden[0] if vorhanden else je_sprache[neu]
        self.cfg["sprache"] = neu
        save_config(self.cfg)

    # --- Pfade ---------------------------------------------------------------
    @property
    def vault(self) -> Path:
        return Path(self.cfg["vault_path"]).expanduser()

    @property
    def db_path(self) -> Path:
        p = Path(self.cfg["db_path"]).expanduser()
        return p if p.is_absolute() else BASE_DIR / p

    def vault_ok(self) -> bool:
        return self.vault.is_dir()

    def ordner(self, key: str) -> Path:
        name = self.cfg.get(key) or ORDNER_STANDARD[key][self.sprache]
        return self.vault / name

    def rel(self, p: Path) -> str:
        return p.relative_to(self.vault).as_posix()

    def abs_in_vault(self, rel: str) -> Path:
        p = (self.vault / (rel or "")).resolve()
        if self.vault.resolve() not in p.parents:
            raise ValueError(self._("Pfad liegt ausserhalb des Vaults."))
        return p

    def obsidian_link(self, rel: str) -> str:
        name = (self.cfg.get("obsidian_vault_name") or "").strip()
        params = {"vault": name, "file": rel} if name else {"path": str(self.vault / rel)}
        return "obsidian://open?" + urllib.parse.urlencode(params, quote_via=urllib.parse.quote)

    # --- DB ------------------------------------------------------------------
    def db(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.db_path, timeout=30)
        con.row_factory = sqlite3.Row
        return con

    def _init_db(self):
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self.db() as con:
            alt = {r[1] for r in con.execute("PRAGMA table_info(notizen)")}
            if alt and "kunde" not in alt:  # Datenbank der früheren Projekt-Version: neu aufbauen
                con.executescript("DROP TABLE IF EXISTS notizen; DROP TABLE IF EXISTS tasks; "
                                  "DROP TABLE IF EXISTS lcm; DROP TABLE IF EXISTS tagesuebersicht; "
                                  "DROP TABLE IF EXISTS sync_log;")
            con.executescript(SCHEMA)

    # --- Grundstruktur -------------------------------------------------------
    def ensure_basics(self):
        if not self.vault_ok():
            raise FileNotFoundError(self._("Vault nicht gefunden: {pfad}", pfad=self.vault))
        for key in ORDNER_KEYS:
            self.ordner(key).mkdir(parents=True, exist_ok=True)
        self.vorlagen_schreiben(ueberschreiben=False)

    def vorlage_datei(self, typ: str) -> Path:
        return self.ordner("vorlagen_ordner") / f"{vorlagen.DATEINAME[typ][vorlagen.SPRACH_INDEX[self.sprache]]}.md"

    def vorlagen_schreiben(self, ueberschreiben: bool = False) -> int:
        n = 0
        self.ordner("vorlagen_ordner").mkdir(parents=True, exist_ok=True)
        for typ in vorlagen.TYPEN:
            f = self.vorlage_datei(typ)
            if ueberschreiben or not f.exists():
                f.write_text(vorlagen.vorlage(typ, self.sprache), encoding="utf-8")
                n += 1
        return n

    @staticmethod
    def _unique(path: Path) -> Path:
        kandidat, i = path, 2
        while kandidat.exists():
            kandidat = path.with_name(f"{path.stem}_{i}{path.suffix}")
            i += 1
        return kandidat

    def _notiz_anlegen(self, typ: str, titel: str, werte: dict, dateiname: str | None = None) -> Path:
        self.ensure_basics()
        titel = (titel or "").strip()
        if not titel:
            raise ValueError(self._("Bitte einen Titel eingeben."))
        info = vorlagen.TYPEN[typ]
        ziel = self.ordner(info["ordner"])
        ziel.mkdir(parents=True, exist_ok=True)
        praefix = vorlagen.PRAEFIX[typ][vorlagen.SPRACH_INDEX[self.sprache]]
        datei = self._unique(ziel / f"{dateiname or praefix + safe_name(titel, True)}.md")
        f = self.vorlage_datei(typ)
        text = f.read_text(encoding="utf-8") if f.exists() else vorlagen.vorlage(typ, self.sprache)
        werte = {"title": titel, "date": dt.date.today().isoformat(), **werte}
        for k, v in werte.items():
            text = text.replace("{{" + k + "}}", "" if v is None else str(v))
        text = re.sub(r"\{\{[a-z_]+\}\}", "", text)
        text = text.replace('""', "")  # leere Links in Anführungszeichen
        text = re.sub(r"[ \t]+$", "", text, flags=re.M)
        text = set_frontmatter(text, {"typ": typ, **({} if typ == "kunde" else {"titel": titel})})
        datei.write_text(text, encoding="utf-8")
        with self.db() as con:
            self._index_file(con, datei)
        return datei

    # --- Kunden ----------------------------------------------------------------
    def _kunden_link(self, kunde: str) -> str:
        k = self.kunde_finden(kunde)
        return f"[[{k['key']}]]" if k else (f"[[{kunde}]]" if kunde else "")

    def kunde_anlegen(self, d: dict) -> Path:
        name = (d.get("name") or "").strip()
        if self.kunde_finden(name):
            raise ValueError(self._("Diesen Kunden gibt es bereits."))
        return self._notiz_anlegen("kunde", name, {
            "name": name, "branche": d.get("branche", ""),
            "sla_level": code(d.get("sla_level"), SLA_STUFEN), "status": code(d.get("status"), KUNDEN_STATUS, "gruen"),
            "vertragsende": iso(parse_date(d.get("vertragsende"))),
            "kuendigungsfrist_monate": d.get("kuendigungsfrist_monate", ""),
            "jahresumsatz": d.get("jahresumsatz", ""), "sdm_lead": d.get("sdm_lead", ""),
            "account_manager": d.get("account_manager", "")})

    def _roh(self, typ: str) -> list[dict]:
        with self.db() as con:
            rows = con.execute("SELECT pfad, titel, kunde, geaendert, meta FROM notizen WHERE typ=? "
                               "ORDER BY titel COLLATE NOCASE", (typ,)).fetchall()
        out = []
        for r in rows:
            d = json.loads(r["meta"] or "{}")
            d.update(pfad=r["pfad"], titel=r["titel"], kunde_key=r["kunde"] or "", geaendert=r["geaendert"],
                     link=self.obsidian_link(r["pfad"]), key=Path(r["pfad"]).stem)
            out.append(d)
        return out

    def _kunden_index(self) -> dict[str, dict]:
        idx = {}
        for k in self._roh("kunde"):
            idx[k["key"].lower()] = k
            idx[k["titel"].lower()] = k
        return idx

    def kunde_finden(self, wert: str) -> dict | None:
        w = link_name(wert).lower()
        return self._kunden_index().get(w) if w else None

    def kunden(self, heute: dt.date | None = None) -> list[dict]:
        heute = heute or dt.date.today()
        assets = self.assets(heute)
        opps = self.opportunities(heute)
        esk = [e for e in self._roh("eskalation") if (e.get("status") or "offen").lower() not in ("geschlossen", "closed", "erledigt")]
        out = []
        for k in self._roh("kunde"):
            kk = k["key"]
            ka = [a for a in assets if a["kunde_key"] == kk]
            ko = [o for o in opps if o["kunde_key"] == kk and o["phase"] not in ("gewonnen", "verloren")]
            k.update(
                name=k.get("name") or k["titel"],
                sla=code(k.get("sla_level"), SLA_STUFEN), status=code(k.get("status"), KUNDEN_STATUS),
                vertragsende_d=parse_date(k.get("vertragsende")),
                assets_kritisch=sum(a["lc"]["klasse"] in ("abgelaufen", "umsetzung", "angebot") for a in ka),
                opps_offen=len(ko), pipeline=sum(o["volumen"] for o in ko),
                pipeline_gewichtet=sum(o["gewichtet"] for o in ko),
                eskalationen=sum(e["kunde_key"] == kk for e in esk),
                naechste=next((a for a in ka if a["lc"]["klasse"] not in ("ok", "unbekannt", "inaktiv")), None),
                jahresumsatz_n=zahl_wert(k.get("jahresumsatz") or k.get("jahresumsatz_chf")))
            out.append(k)
        rang = {"rot": 0, "gelb": 1, "gruen": 2, "": 3}
        out.sort(key=lambda k: (rang.get(k["status"], 3), -k["assets_kritisch"], k["name"].lower()))
        return out

    def kunde(self, key: str, heute: dt.date | None = None) -> dict | None:
        heute = heute or dt.date.today()
        k = next((x for x in self.kunden(heute) if x["key"] == key), None)
        if not k:
            return None
        k["assets"] = [a for a in self.assets(heute) if a["kunde_key"] == key]
        k["opps"] = [o for o in self.opportunities(heute) if o["kunde_key"] == key]
        k["meetings"] = [m for m in self.meetings() if m["kunde_key"] == key]
        k["kontakte"] = [c for c in self.kontakte() if c["kunde_key"] == key]
        k["eskalationen_liste"] = [e for e in self._roh("eskalation") if e["kunde_key"] == key]
        k["aufgaben"] = [a for a in self.aufgaben(heute) if a["kunde"] == key and not a["erledigt"]]
        return k

    # --- Kontakte / Eskalationen ---------------------------------------------
    def kontakte(self) -> list[dict]:
        out = self._roh("kontakt")
        for c in out:
            c["rolle_c"] = code(c.get("rolle"), KONTAKT_ROLLEN)
            c["stimmung_c"] = code(c.get("stimmung"), STIMMUNGEN)
        return out

    def kontakt_anlegen(self, d: dict) -> Path:
        name = (d.get("name") or "").strip()
        return self._notiz_anlegen("kontakt", name, {
            "kunde": self._kunden_link(d.get("kunde", "")), "funktion": d.get("funktion", ""),
            "rolle": code(d.get("rolle"), KONTAKT_ROLLEN), "email": d.get("email", ""),
            "telefon": d.get("telefon", ""), "stimmung": code(d.get("stimmung"), STIMMUNGEN, "neutral"),
            "loeschen_nach": iso(parse_date(d.get("loeschen_nach")))})

    def eskalation_anlegen(self, d: dict) -> Path:
        titel = (d.get("titel") or "").strip()
        heute = dt.date.today().isoformat()
        return self._notiz_anlegen("eskalation", titel, {
            "kunde": self._kunden_link(d.get("kunde", "")), "prioritaet": code(d.get("prioritaet"), ESK_PRIO, "p2"),
            "beschreibung": d.get("beschreibung", "")},
            dateiname=f"Incident_{heute}_{safe_name(titel, True)}")

    # --- Assets / Lifecycle ----------------------------------------------------
    def assets(self, heute: dt.date | None = None) -> list[dict]:
        heute = heute or dt.date.today()
        opps = {o["key"].lower(): o for o in self._roh("opportunity")}
        opp_nach_asset = {}
        for o in opps.values():
            a = link_name(o.get("verknuepftes_asset")).lower()
            if a:
                opp_nach_asset.setdefault(a, o)
        kidx = self._kunden_index()
        out = []
        for a in self._roh("asset"):
            a["lc"] = lc_phase(a, heute)
            a["kategorie_c"] = code(a.get("kategorie"), ASSET_KATEGORIEN)
            if not a.get("produkt_version"):
                a["produkt_version"] = " ".join(x for x in (a.get("produkt"), a.get("version")) if x)
            o = opps.get(link_name(a.get("verknuepfte_opportunity")).lower()) or opp_nach_asset.get(a["key"].lower())
            a["opportunity"] = {"titel": o["titel"], "link": o["link"], "key": o["key"]} if o else None
            k = kidx.get(a["kunde_key"].lower())
            a["kunde_name"] = (k.get("name") or k["titel"]) if k else link_name(a.get("kunde") or a.get("projekt"))
            out.append(a)
        out.sort(key=lambda a: (PHASE_RANG[a["lc"]["klasse"]],
                                a["lc"]["tage"] if a["lc"]["tage"] is not None else 99999))
        return out

    def asset_anlegen(self, d: dict) -> Path:
        titel = (d.get("titel") or "").strip()
        return self._notiz_anlegen("asset", titel, {
            "kunde": self._kunden_link(d.get("kunde", "")),
            "kategorie": code(d.get("kategorie"), ASSET_KATEGORIEN, "hardware"),
            "hersteller": d.get("hersteller", ""), "produkt_version": d.get("produkt_version", ""),
            "anzahl_units": d.get("anzahl_units", ""),
            **{k: iso(parse_date(d.get(k))) for k in ("kauf_start_datum", "end_of_support", "end_of_life",
                                                       "vertragsende", "esu_bis")},
            "kuendigungsfrist_monate": d.get("kuendigungsfrist_monate", ""),
            "kritikalitaet": code(d.get("kritikalitaet"), KRITIKALITAET, "mittel"),
            "betriebsstatus": code(d.get("betriebsstatus"), BETRIEBSSTATUS, "betrieb")})

    # --- Opportunities -----------------------------------------------------------
    def opportunities(self, heute: dt.date | None = None) -> list[dict]:
        heute = heute or dt.date.today()
        kidx = self._kunden_index()
        out = []
        for o in self._roh("opportunity"):
            o["phase"] = code(o.get("phase"), OPP_PHASEN, "qualifizierung")
            w = o.get("wahrscheinlichkeit")
            o["wkeit"] = int(zahl_wert(w)) if str(w or "").strip() else OPP_WKEIT[o["phase"]]
            o["volumen"] = zahl_wert(o.get("volumen") or o.get("volumen_chf"))
            o["gewichtet"] = o["volumen"] * o["wkeit"] / 100
            o["quelle_c"] = code(o.get("quelle"), QUELLEN)
            o["abschluss"] = parse_date(o.get("abschluss_geplant"))
            o["ueberfaellig"] = bool(o["abschluss"] and o["abschluss"] < heute and o["phase"] not in ("gewonnen", "verloren"))
            a = link_name(o.get("verknuepftes_asset"))
            o["asset"] = {"titel": re.sub(rf"^({'|'.join(vorlagen.ALLE_PRAEFIXE)})_", "", a).replace("_", " "), "key": a} if a else None
            k = kidx.get(o["kunde_key"].lower())
            o["kunde_name"] = (k.get("name") or k["titel"]) if k else link_name(o.get("kunde"))
            out.append(o)
        out.sort(key=lambda o: (o["abschluss"] or dt.date.max, -o["volumen"]))
        return out

    def opportunity_anlegen(self, d: dict) -> Path:
        titel = (d.get("titel") or "").strip()
        phase = code(d.get("phase"), OPP_PHASEN, "qualifizierung")
        asset_rel = (d.get("asset") or "").strip()
        asset_link, ausloeser = "", ""
        if asset_rel:
            ap = self.abs_in_vault(asset_rel)
            asset_link = f"[[{ap.stem}]]"
            ausloeser = self._("Lifecycle von {asset}", asset=asset_link)
        p = self._notiz_anlegen("opportunity", titel, {
            "kunde": self._kunden_link(d.get("kunde", "")), "phase": phase,
            "wahrscheinlichkeit": d.get("wahrscheinlichkeit") or OPP_WKEIT[phase],
            "volumen": d.get("volumen", ""), "abschluss_geplant": iso(parse_date(d.get("abschluss_geplant"))),
            "quelle": code(d.get("quelle"), QUELLEN, "lifecycle" if asset_rel else "bestandskunde"),
            "verknuepftes_asset": asset_link, "ausloeser": ausloeser})
        if asset_rel:  # Rückverweis im Asset
            ap = self.abs_in_vault(asset_rel)
            ap.write_text(set_frontmatter(ap.read_text(encoding="utf-8"),
                                          {"verknuepfte_opportunity": f"[[{p.stem}]]"}), encoding="utf-8")
            with self.db() as con:
                self._index_file(con, ap)
        return p

    def opportunity_phase(self, rel: str, phase: str) -> None:
        phase = code(phase, OPP_PHASEN)
        if not phase:
            raise ValueError(self._("Ungültige Phase."))
        p = self.abs_in_vault(rel)
        fm, _ = parse_frontmatter(p.read_text(encoding="utf-8"))
        if TYP_ALIAS.get((fm.get("typ") or "").lower(), (fm.get("typ") or "").lower()) != "opportunity":
            raise ValueError(self._("Diese Notiz ist keine Opportunity."))
        werte = {"phase": phase}
        if phase in ("gewonnen", "verloren"):
            werte["wahrscheinlichkeit"] = OPP_WKEIT[phase]
        p.write_text(set_frontmatter(p.read_text(encoding="utf-8"), werte), encoding="utf-8")
        with self.db() as con:
            self._index_file(con, p)

    # --- Meetings ----------------------------------------------------------------
    def meetings(self) -> list[dict]:
        out = self._roh("meeting")
        kidx = self._kunden_index()
        for m in out:
            m["datum_d"] = parse_date(m.get("datum"))
            m["art_c"] = code(m.get("art"), MEETING_ARTEN, "jour_fixe")
            k = kidx.get(m["kunde_key"].lower())
            m["kunde_name"] = (k.get("name") or k["titel"]) if k else link_name(m.get("kunde"))
        out.sort(key=lambda m: m["datum_d"] or dt.date.min, reverse=True)
        return out

    def meeting_anlegen(self, d: dict) -> Path:
        heute = dt.date.today()
        datum = parse_date(d.get("datum")) or heute
        art = code(d.get("art"), MEETING_ARTEN, "jour_fixe")
        k = self.kunde_finden(d.get("kunde", ""))
        kname = (k.get("name") or k["titel"]) if k else (d.get("kunde") or "").strip()
        titel = (d.get("titel") or "").strip() or f"{self.label(art)} {kname}".strip()
        lc_zeilen, auf_zeilen = [], []
        if k:
            for a in self.assets(heute):
                if a["kunde_key"] == k["key"] and a["lc"]["klasse"] in ("abgelaufen", "umsetzung", "angebot", "strategie"):
                    lc_zeilen.append(f"   - [[{a['key']}|{a['titel']}]] · {self._(PHASE_TEXT[a['lc']['klasse']])}"
                                     f" · {self.dmy(a['lc']['frist'])}")
            for t in self.aufgaben(heute):
                if t["kunde"] == k["key"] and not t["erledigt"]:
                    auf_zeilen.append(f"- [[{t['datei']}]]: {t['text']}"
                                      + (f" ({self.dmy(t['faellig'])})" if t["faellig"] else ""))
        return self._notiz_anlegen("meeting", titel, {
            "kunde": self._kunden_link(kname), "art": art, "datum": datum.isoformat(),
            "teilnehmer": d.get("teilnehmer", ""),
            "lifecycle": "\n".join(lc_zeilen) or "   - " + self._("keine offenen Lifecycle-Themen"),
            "offene_aufgaben": "\n".join(auf_zeilen) or "- " + self._("keine")},
            dateiname=f"{datum.isoformat()}_{safe_name(self.label(art), True)}_{safe_name(kname or titel, True)}")

    # --- Aufgaben (Checkbox-Zeilen, kompatibel mit Obsidian Tasks) ---------------
    def aufgaben(self, heute: dt.date | None = None, kunde: str = "") -> list[dict]:
        heute = heute or dt.date.today()
        sql, args = "SELECT * FROM aufgaben", []
        if kunde:
            sql += " WHERE kunde=?"
            args.append(kunde)
        with self.db() as con:
            rows = [dict(r) for r in con.execute(sql, args)]
        kidx = self._kunden_index()
        for t in rows:
            t["faellig_d"] = parse_date(t["faellig"])
            t["datei"] = Path(t["pfad"]).stem
            t["link"] = self.obsidian_link(t["pfad"])
            t["rest"] = (t["faellig_d"] - heute).days if t["faellig_d"] else None
            k = kidx.get((t["kunde"] or "").lower())
            t["kunde_name"] = (k.get("name") or k["titel"]) if k else ""
            if t["erledigt"]:
                t["gruppe"] = "erledigt"
            elif t["rest"] is None:
                t["gruppe"] = "ohne_datum"
            elif t["rest"] < 0:
                t["gruppe"] = "ueberfaellig"
            elif t["rest"] == 0:
                t["gruppe"] = "heute"
            else:
                t["gruppe"] = "geplant"
        rows.sort(key=lambda t: (t["faellig"] or "9999", t["text"].lower()))
        return rows

    def aufgabe_umschalten(self, rel: str, zeile: int, roh: str) -> None:
        p = self.abs_in_vault(rel)
        zeilen = p.read_text(encoding="utf-8").split("\n")
        if zeile >= len(zeilen) or zeilen[zeile].rstrip("\r") != roh:
            raise ValueError(self._("Die Notiz wurde inzwischen geändert. Bitte «Jetzt aktualisieren» und erneut versuchen."))
        cr = "\r" if zeilen[zeile].endswith("\r") else ""
        m = TASK_RE.match(roh)
        if not m:
            raise ValueError(self._("Zeile ist keine Aufgabe."))
        if m.group(2) == " ":
            neu = f"{m.group(1)}x{m.group(3)}{m.group(4).rstrip()} ✅ {dt.date.today().isoformat()}"
        else:
            neu = f"{m.group(1)} {m.group(3)}{ERLEDIGT_RE.sub('', m.group(4)).rstrip()}"
        zeilen[zeile] = neu + cr
        p.write_text("\n".join(zeilen), encoding="utf-8")
        with self.db() as con:
            self._index_file(con, p)

    def aufgabe_anlegen(self, text: str, faellig: str = "", ziel_rel: str = "") -> Path:
        """Hängt '- [ ] Text 📅 Datum' an den Abschnitt «✅ …» der Zielnotiz (Kunde, Asset, Opportunity …)."""
        text = " ".join((text or "").split())
        if not text:
            raise ValueError(self._("Bitte einen Text eingeben."))
        self.ensure_basics()
        if ziel_rel:
            p = self.abs_in_vault(ziel_rel)
        else:
            p = self.ordner("planer_ordner") / f"{self._('Aufgaben')}.md"
            if not p.exists():
                p.write_text(f"# {self._('Aufgaben')}\n\n## ✅ {self._('Aufgaben & Next Steps')}\n", encoding="utf-8")
        d = parse_date(faellig)
        zeile = f"- [ ] {text}" + (f" 📅 {d.isoformat()}" if d else "")
        inhalt = p.read_text(encoding="utf-8").rstrip("\n").split("\n")
        idx = next((i for i, z in enumerate(inhalt) if z.startswith("## ") and "✅" in z), None)
        if idx is None:
            inhalt += ["", f"## ✅ {self._('Aufgaben & Next Steps')}", zeile]
        else:
            ende = next((i for i in range(idx + 1, len(inhalt)) if inhalt[i].startswith("#")), len(inhalt))
            while ende > idx + 1 and not inhalt[ende - 1].strip():
                ende -= 1
            inhalt.insert(ende, zeile)
        p.write_text("\n".join(inhalt) + "\n", encoding="utf-8")
        with self.db() as con:
            self._index_file(con, p)
        return p

    # --- Suche ---------------------------------------------------------------------
    def suche(self, q: str, limit: int = 100) -> list[dict]:
        woerter = q.split()
        if not woerter:
            return []
        sql, args = "SELECT pfad, titel, typ, kunde, inhalt FROM notizen WHERE typ != 'cockpit'", []
        for w in woerter:
            sql += " AND (titel LIKE ? OR inhalt LIKE ? OR pfad LIKE ? OR meta LIKE ?)"
            args += [f"%{w}%"] * 4
        sql += " ORDER BY geaendert DESC LIMIT ?"
        args.append(limit)
        out = []
        kidx = self._kunden_index()
        with self.db() as con:
            for r in con.execute(sql, args):
                inhalt = r["inhalt"] or ""
                pos = inhalt.lower().find(woerter[0].lower())
                k = kidx.get((r["kunde"] or "").lower())
                out.append({"pfad": r["pfad"], "titel": r["titel"], "typ": r["typ"], "kunde": r["kunde"],
                            "kunde_name": (k.get("name") or k["titel"]) if k else "",
                            "snippet": (inhalt[max(0, pos - 80): pos + 160] if pos >= 0 else inhalt[:200]).replace("\n", " "),
                            "link": self.obsidian_link(r["pfad"]),
                            "score": sum(w.lower() in (r["titel"] or "").lower() for w in woerter)})
        out.sort(key=lambda x: -x["score"])
        return out

    # --- Index ---------------------------------------------------------------------
    def _iter_md(self):
        skip = {".obsidian", ".trash", ".git", "node_modules"}
        for p in self.vault.rglob("*.md"):
            if not any(part in skip for part in p.relative_to(self.vault).parts):
                yield p

    def _ist_vorlage(self, rel: str) -> bool:
        return rel.startswith((self.cfg.get("vorlagen_ordner") or "99_Vorlagen") + "/")

    def _index_file(self, con: sqlite3.Connection, p: Path):
        rel = self.rel(p)
        con.execute("DELETE FROM aufgaben WHERE pfad=?", (rel,))
        con.execute("DELETE FROM notizen WHERE pfad=?", (rel,))
        if not p.exists() or self._ist_vorlage(rel):
            return
        text = p.read_text(encoding="utf-8", errors="replace")
        fm, body = parse_frontmatter(text)
        typ = (fm.get("typ") or fm.get("type") or "").lower()
        typ = TYP_ALIAS.get(typ, typ)
        if not typ and p.name.lower().startswith("lcm_"):
            typ = "asset"
        titel = fm.get("titel") or fm.get("title") or (fm.get("name") if typ == "kunde" else "") or \
            re.sub(rf"^({'|'.join(vorlagen.ALLE_PRAEFIXE)})_", "", p.stem).replace("_", " ")
        if typ == "kunde":
            kunde = p.stem
        else:
            kunde = link_name(fm.get("kunde") or fm.get("customer") or fm.get("projekt"))
            if kunde:  # Name oder Alias -> Dateiname der Kundennotiz
                for r in con.execute("SELECT pfad, titel, meta FROM notizen WHERE typ='kunde'"):
                    stem = Path(r["pfad"]).stem
                    name = json.loads(r["meta"] or "{}").get("name") or ""
                    if kunde.lower() in (stem.lower(), (r["titel"] or "").lower(), name.lower()):
                        kunde = stem
                        break
        geaendert = dt.datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds")
        con.execute("INSERT OR REPLACE INTO notizen VALUES (?,?,?,?,?,?,?)",
                    (rel, titel, typ or "notiz", kunde, geaendert, body, json.dumps(fm, ensure_ascii=False)))
        offset = text[:len(text) - len(body)].count("\n")
        for i, zeile in enumerate(body.split("\n")):
            z = zeile.rstrip("\r")
            m = TASK_RE.match(z)
            if not m or not m.group(4).strip():
                continue
            faellig = FAELLIG_RE.search(z)
            klartext = EMOJI_META_RE.sub("", m.group(4)).strip()
            if not klartext:
                continue
            con.execute("INSERT OR REPLACE INTO aufgaben VALUES (?,?,?,?,?,?,?)",
                        (rel, offset + i, klartext, z, faellig.group(1) if faellig else None,
                         int(m.group(2).lower() == "x"), kunde))

    def _kunden_keys_aufloesen(self, con: sqlite3.Connection):
        """Kundenverweise ('Muster AG' oder '[[Kunde_Muster_AG]]') auf den Dateinamen des Kunden abbilden."""
        idx = {}
        for r in con.execute("SELECT pfad, titel, meta FROM notizen WHERE typ='kunde'"):
            key = Path(r["pfad"]).stem
            meta = json.loads(r["meta"] or "{}")
            for alias in (key, r["titel"], meta.get("name") or ""):
                if alias:
                    idx[alias.lower()] = key
        for tabelle in ("notizen", "aufgaben"):
            for (k,) in con.execute(f"SELECT DISTINCT kunde FROM {tabelle} WHERE kunde != ''").fetchall():
                ziel = idx.get(k.lower())
                if ziel and ziel != k:
                    con.execute(f"UPDATE {tabelle} SET kunde=? WHERE kunde=?", (ziel, k))

    # --- Cockpit-Notiz (Heute.md) ------------------------------------------------
    def _heute_notiz(self, heute: dt.date):
        _ = self._
        n = int(self.cfg.get("demnaechst_tage", 7))
        auf = [t for t in self.aufgaben(heute) if t["gruppe"] in ("ueberfaellig", "heute")
               or (t["gruppe"] == "geplant" and t["rest"] <= n)]
        lc = [a for a in self.assets(heute) if a["lc"]["klasse"] in ("abgelaufen", "umsetzung", "angebot")]
        opps = [o for o in self.opportunities(heute) if o["ueberfaellig"]]
        meet = [m for m in self.meetings() if m["datum_d"] and 0 <= (m["datum_d"] - heute).days <= n]
        wt = _(WOCHENTAGE[heute.weekday()])
        z = ["---", "typ: cockpit", f"datum: {heute.isoformat()}",
             f"aktualisiert: {dt.datetime.now().isoformat(timespec='minutes')}", "---",
             f"# {_('Heute')} · {wt}, {self.dmy(heute)}",
             f"> {_('Automatisch erzeugt – Änderungen in dieser Datei werden beim nächsten Sync überschrieben.')}", ""]
        z += [f"## ✅ {_('Fällige Aufgaben')} ({len(auf)})"]
        z += [f"- [[{t['datei']}]] · {t['text']}" + (f" · {self.dmy(t['faellig'])}" if t["faellig"] else "")
              for t in auf] or ["- –"]
        z += ["", f"## ♻️ {_('Lifecycle-Aktionen')} ({len(lc)})"]
        z += [f"- [[{a['key']}|{a['titel']}]] · {a['kunde_name']} · {_(PHASE_TEXT[a['lc']['klasse']])}"
              f" · {self.dmy(a['lc']['frist'])}" + ("" if a["opportunity"] else f" · ⚠️ {_('ohne Opportunity')}")
              for a in lc] or ["- –"]
        z += ["", f"## 💰 {_('Opportunities mit überfälligem Abschluss')} ({len(opps)})"]
        z += [f"- [[{o['key']}|{o['titel']}]] · {o['kunde_name']} · {self.dmy(o['abschluss'])}" for o in opps] or ["- –"]
        z += ["", f"## 🤝 {_('Meetings in den nächsten {n} Tagen', n=n)} ({len(meet)})"]
        z += [f"- {self.dmy(m['datum_d'])} · [[{m['key']}|{m['titel']}]]" for m in sorted(meet, key=lambda m: m["datum_d"])] or ["- –"]
        pdir = self.ordner("planer_ordner")
        pdir.mkdir(parents=True, exist_ok=True)
        ziel = pdir / f"{_('Heute')}.md"
        for code in i18n.SPRACHEN:  # Cockpit-Datei einer früher eingestellten Sprache entfernen
            alt = pdir / f"{i18n.t(code, 'Heute')}.md"
            if alt != ziel and alt.exists() and "typ: cockpit" in alt.read_text(encoding="utf-8", errors="replace")[:200]:
                alt.unlink()
        ziel.write_text("\n".join(z) + "\n", encoding="utf-8")

    # --- Sync ------------------------------------------------------------------------
    def sync(self, art: str = "manuell") -> dict:
        with self._lock:
            t0 = time.time()
            heute = dt.date.today()
            self.ensure_basics()
            dateien = 0
            with self.db() as con:
                con.execute("DELETE FROM notizen")
                con.execute("DELETE FROM aufgaben")
                for p in self._iter_md():
                    try:
                        self._index_file(con, p)
                        dateien += 1
                    except Exception as exc:  # eine defekte Datei soll den Sync nicht stoppen
                        print(f"[WARN] {p}: {exc}", file=sys.stderr)
                self._kunden_keys_aufloesen(con)
            self._heute_notiz(heute)
            auf = self.aufgaben(heute)
            stats = {"zeitpunkt": dt.datetime.now().isoformat(timespec="seconds"), "art": art,
                     "dateien": dateien, "aufgaben_offen": sum(not t["erledigt"] for t in auf),
                     "aufgaben_faellig": sum(t["gruppe"] in ("heute", "ueberfaellig") for t in auf),
                     "assets": len(self._roh("asset")), "dauer_ms": int((time.time() - t0) * 1000)}
            with self.db() as con:
                con.execute("INSERT INTO sync_log (zeitpunkt, art, dateien, aufgaben_offen, aufgaben_faellig, "
                            "assets, dauer_ms) VALUES (:zeitpunkt,:art,:dateien,:aufgaben_offen,"
                            ":aufgaben_faellig,:assets,:dauer_ms)", stats)
            return stats

    def sync_log(self, limit: int = 20) -> list[dict]:
        with self.db() as con:
            return [dict(r) for r in con.execute("SELECT * FROM sync_log ORDER BY id DESC LIMIT ?", (limit,))]

    def letzter_sync(self) -> dict | None:
        log = self.sync_log(1)
        return log[0] if log else None

    def geplanter_sync_faellig(self, jetzt: dt.datetime | None = None) -> bool:
        jetzt = jetzt or dt.datetime.now()
        h, m = (int(x) for x in str(self.cfg.get("sync_zeit", "04:00")).split(":"))
        slot = jetzt.replace(hour=h, minute=m, second=0, microsecond=0)
        if jetzt < slot:
            slot -= dt.timedelta(days=1)
        with self.db() as con:
            last = con.execute("SELECT MAX(zeitpunkt) FROM sync_log WHERE art='geplant'").fetchone()[0]
        return last is None or dt.datetime.fromisoformat(last) < slot

    def starte_scheduler(self):
        def loop():
            while True:
                try:
                    if self.vault_ok() and self.geplanter_sync_faellig():
                        self.sync("geplant")
                except Exception as exc:
                    print(f"[Agent] Sync: {exc}", file=sys.stderr)
                time.sleep(60)
        threading.Thread(target=loop, daemon=True, name="agent-scheduler").start()


PHASE_TEXT = {"abgelaufen": "Abgelaufen", "umsetzung": "Umsetzung", "angebot": "Angebot",
              "strategie": "Strategie", "ok": "OK", "unbekannt": "Kein Datum", "inaktiv": "Ausser Betrieb"}
WOCHENTAGE = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"]


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description="Obsidian-Agent SDM")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("sync")
    s.add_argument("--geplant", action="store_true")
    sub.add_parser("heute")
    sp = sub.add_parser("sprache")
    sp.add_argument("code", choices=list(i18n.SPRACHEN))
    a = ap.parse_args(argv)

    agent = Agent()
    _ = agent._
    if a.cmd == "sync":
        st = agent.sync("geplant" if a.geplant else "manuell")
        print(f"Sync OK – {st['dateien']} · {_('Fällige Aufgaben')}: {st['aufgaben_faellig']} · {st['dauer_ms']} ms")
    elif a.cmd == "heute":
        for t in agent.aufgaben():
            if t["gruppe"] in ("ueberfaellig", "heute"):
                print(f"  {agent.dmy(t['faellig'])}  {t['text']}  ({t['kunde_name'] or t['datei']})")
    elif a.cmd == "sprache":
        agent.sprache_setzen(a.code)
        print(f"OK: {i18n.SPRACHEN[a.code]}")


if __name__ == "__main__":
    main()
