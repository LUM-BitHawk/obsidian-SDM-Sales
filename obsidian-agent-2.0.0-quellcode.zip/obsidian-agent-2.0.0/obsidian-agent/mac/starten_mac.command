#!/bin/bash
# Obsidian-Agent SDM starten (macOS, Doppelklick im Finder)
cd "$(dirname "$0")/.." || exit 1
if [ ! -x .venv/bin/python ]; then
  exec "$(pwd)/mac/installieren_mac.command"
fi
PORT=$(.venv/bin/python -c "import agent; print(agent.load_config().get('port', 5055))" 2>/dev/null || echo 5055)
# Läuft der Agent schon (z.B. per Autostart)? Dann nur den Browser öffnen.
if lsof -nP -iTCP:"$PORT" -sTCP:LISTEN >/dev/null 2>&1; then
  open "http://127.0.0.1:$PORT"
  exit 0
fi
exec .venv/bin/python app.py
