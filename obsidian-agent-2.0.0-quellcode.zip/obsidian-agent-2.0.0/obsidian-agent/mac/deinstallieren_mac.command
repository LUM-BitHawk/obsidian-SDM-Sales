#!/bin/bash
# ======================================================================
#  Obsidian-Agent SDM – Deinstallation (macOS)
#  - beendet den Agent, entfernt Autostart und täglichen Sync (launchd)
#  - sichert config.json und planer.db auf den Schreibtisch
#  - entfernt die Python-Umgebung und auf Wunsch den Programmordner
#  Der Obsidian-Vault wird NICHT verändert.
# ======================================================================
cd "$(dirname "$0")/.." || exit 1
DIR="$(pwd)"
LA="$HOME/Library/LaunchAgents"
UIDN="$(id -u)"
SPRACHE=$(grep -o '"sprache": *"[a-z]*"' config.json 2>/dev/null | grep -o '"[a-z]*"$' | tr -d '"')
case "$SPRACHE" in de|en|fr|it|es|ro) ;; *) SPRACHE=de ;; esac

t() {
  case "$SPRACHE:$1" in
    de:titel) echo "Obsidian-Agent SDM deinstallieren";; en:titel) echo "Uninstall Obsidian-Agent SDM";;
    fr:titel) echo "Désinstaller Obsidian-Agent SDM";; it:titel) echo "Disinstallare Obsidian-Agent SDM";;
    es:titel) echo "Desinstalar Obsidian-Agent SDM";; ro:titel) echo "Dezinstalare Obsidian-Agent SDM";;
    de:vault) echo "Dein Obsidian-Vault bleibt unverändert.";; en:vault) echo "Your Obsidian vault stays unchanged.";;
    fr:vault) echo "Votre coffre Obsidian reste inchangé.";; it:vault) echo "Il tuo vault Obsidian resta invariato.";;
    es:vault) echo "Su bóveda de Obsidian no se modifica.";; ro:vault) echo "Seiful Obsidian rămâne neschimbat.";;
    de:weiter) echo "Fortfahren? (j/n) ";; en:weiter) echo "Continue? (y/n) ";; fr:weiter) echo "Continuer ? (o/n) ";;
    it:weiter) echo "Continuare? (s/n) ";; es:weiter) echo "¿Continuar? (s/n) ";; ro:weiter) echo "Continuați? (d/n) ";;
    de:backup) echo "Sicherung";; en:backup) echo "Backup";; fr:backup) echo "Sauvegarde";; it:backup) echo "Backup";;
    es:backup) echo "Copia de seguridad";; ro:backup) echo "Copie de rezervă";;
    de:ordner) echo "Programmordner komplett löschen? (j/n) ";; en:ordner) echo "Delete the whole program folder? (y/n) ";;
    fr:ordner) echo "Supprimer tout le dossier du programme ? (o/n) ";; it:ordner) echo "Eliminare l'intera cartella del programma? (s/n) ";;
    es:ordner) echo "¿Eliminar toda la carpeta del programa? (s/n) ";; ro:ordner) echo "Ștergeți tot folderul programului? (d/n) ";;
    de:fertig) echo "Deinstallation abgeschlossen.";; en:fertig) echo "Uninstall complete.";; fr:fertig) echo "Désinstallation terminée.";;
    it:fertig) echo "Disinstallazione completata.";; es:fertig) echo "Desinstalación completada.";; ro:fertig) echo "Dezinstalare finalizată.";;
  esac
}
ja() { [[ "$1" == [jJyYoOsSdD]* ]]; }

echo ""
echo "=== $(t titel) ==="
echo "$DIR"
echo "$(t vault)"
read -r -p "$(t weiter)" OK
ja "$OK" || exit 0

PORT=$(grep -o '"port": *[0-9]*' config.json 2>/dev/null | grep -o '[0-9]*$')
PORT=${PORT:-5055}
for L in ch.obsidian-agent.gui ch.obsidian-agent.sync; do
  if [ -f "$LA/$L.plist" ]; then
    launchctl bootout "gui/$UIDN/$L" 2>/dev/null || launchctl unload "$LA/$L.plist" 2>/dev/null
    rm -f "$LA/$L.plist" && echo "✅ $L"
  fi
done
PIDS=$(lsof -ti tcp:"$PORT" -sTCP:LISTEN 2>/dev/null)
[ -n "$PIDS" ] && kill $PIDS 2>/dev/null && echo "✅ PID $PIDS"

BACKUP="$HOME/Desktop/obsidian-agent-backup_$(date +%Y-%m-%d_%H%M)"
mkdir -p "$BACKUP"
for f in config.json planer.db; do [ -f "$f" ] && cp "$f" "$BACKUP/"; done
echo "✅ $(t backup): $BACKUP"
rm -rf .venv __pycache__ "$HOME/Library/Logs/obsidian-agent"

read -r -p "$(t ordner)" DEL
if ja "$DEL"; then
  cd "$HOME" && rm -rf "$DIR" && echo "✅ $DIR"
fi
echo ""
echo "$(t fertig)"
