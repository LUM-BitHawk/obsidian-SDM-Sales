#!/bin/bash
# ======================================================================
#  Obsidian-Agent SDM – Einrichtung für macOS (Doppelklick im Finder oder vom .pkg gestartet)
#  - prüft Python, legt die Python-Umgebung (.venv) an
#  - setzt die Sprache (Parameter, sonst Systemsprache) und fragt nach dem Obsidian-Vault
#  - richtet den täglichen Sync per launchd ein (läuft nach dem Aufwachen nach)
#  - optional: Agent bei jeder Anmeldung automatisch im Hintergrund starten
#  Aufruf: installieren_mac.command [de|en|fr|it|es|ro]
# ======================================================================
cd "$(dirname "$0")/.." || exit 1
DIR="$(pwd)"
LA="$HOME/Library/LaunchAgents"
LOGDIR="$HOME/Library/Logs/obsidian-agent"
UIDN="$(id -u)"
SYNC_LABEL="ch.obsidian-agent.sync"
GUI_LABEL="ch.obsidian-agent.gui"

# --- Sprache ---------------------------------------------------------------
SPRACHE="${1:-$OBSIDIAN_AGENT_SPRACHE}"
if [ -z "$SPRACHE" ] && [ -f config.json ]; then
  SPRACHE=$(grep -o '"sprache": *"[a-z]*"' config.json | grep -o '"[a-z]*"$' | tr -d '"')
fi
[ -z "$SPRACHE" ] && SPRACHE=$(defaults read -g AppleLanguages 2>/dev/null | sed -n '2p' | tr -d ' ",' | cut -c1-2)
case "$SPRACHE" in de|en|fr|it|es|ro) ;; *) SPRACHE=de ;; esac

t() {  # t <schlüssel>
  case "$SPRACHE:$1" in
    de:titel) echo "Obsidian-Agent SDM – Einrichtung (macOS)";;
    en:titel) echo "Obsidian-Agent SDM – Setup (macOS)";;
    fr:titel) echo "Obsidian-Agent SDM – Installation (macOS)";;
    it:titel) echo "Obsidian-Agent SDM – Installazione (macOS)";;
    es:titel) echo "Obsidian-Agent SDM – Instalación (macOS)";;
    ro:titel) echo "Obsidian-Agent SDM – Instalare (macOS)";;
    de:ordner) echo "Programmordner";; en:ordner) echo "Program folder";; fr:ordner) echo "Dossier du programme";;
    it:ordner) echo "Cartella del programma";; es:ordner) echo "Carpeta del programa";; ro:ordner) echo "Folderul programului";;
    de:nopy) echo "Python 3.9 oder neuer wurde nicht gefunden. Installer: https://www.python.org/downloads/macos/ oder im Terminal: brew install python. Danach die Einrichtung erneut starten.";;
    en:nopy) echo "Python 3.9 or newer was not found. Installer: https://www.python.org/downloads/macos/ or in Terminal: brew install python. Then run the setup again.";;
    fr:nopy) echo "Python 3.9 ou plus récent est introuvable. Installateur : https://www.python.org/downloads/macos/ ou dans le Terminal : brew install python. Relancez ensuite l'installation.";;
    it:nopy) echo "Python 3.9 o successivo non trovato. Installer: https://www.python.org/downloads/macos/ oppure nel Terminale: brew install python. Poi riavviare l'installazione.";;
    es:nopy) echo "No se encontró Python 3.9 o superior. Instalador: https://www.python.org/downloads/macos/ o en Terminal: brew install python. Después vuelva a iniciar la instalación.";;
    ro:nopy) echo "Python 3.9 sau mai nou nu a fost găsit. Instalator: https://www.python.org/downloads/macos/ sau în Terminal: brew install python. Apoi reporniți instalarea.";;
    de:venv) echo "Python-Umgebung wird eingerichtet";; en:venv) echo "Setting up the Python environment";;
    fr:venv) echo "Préparation de l'environnement Python";; it:venv) echo "Preparazione dell'ambiente Python";;
    es:venv) echo "Preparando el entorno de Python";; ro:venv) echo "Se pregătește mediul Python";;
    de:pipfail) echo "Installation von Flask fehlgeschlagen (Internet?)";; en:pipfail) echo "Installing Flask failed (internet?)";;
    fr:pipfail) echo "L'installation de Flask a échoué (Internet ?)";; it:pipfail) echo "Installazione di Flask non riuscita (Internet?)";;
    es:pipfail) echo "La instalación de Flask ha fallado (¿Internet?)";; ro:pipfail) echo "Instalarea Flask a eșuat (internet?)";;
    de:pyok) echo "Abhängigkeiten installiert";; en:pyok) echo "Dependencies installed";; fr:pyok) echo "Dépendances installées";;
    it:pyok) echo "Dipendenze installate";; es:pyok) echo "Dependencias instaladas";; ro:pyok) echo "Dependențe instalate";;
    de:vaultdlg) echo "Bitte den Obsidian-Vault-Ordner wählen:";; en:vaultdlg) echo "Please select your Obsidian vault folder:";;
    fr:vaultdlg) echo "Veuillez choisir le dossier de votre coffre Obsidian :";; it:vaultdlg) echo "Selezionare la cartella del vault Obsidian:";;
    es:vaultdlg) echo "Seleccione la carpeta de su bóveda de Obsidian:";; ro:vaultdlg) echo "Selectați folderul seifului Obsidian:";;
    de:novault) echo "Kein Vault gewählt – der Pfad kann später unter Einstellungen gesetzt werden.";;
    en:novault) echo "No vault selected – you can set the path later in the settings.";;
    fr:novault) echo "Aucun coffre choisi – le chemin peut être défini plus tard dans les paramètres.";;
    it:novault) echo "Nessun vault selezionato – il percorso si può impostare più tardi nelle impostazioni.";;
    es:novault) echo "No se seleccionó ninguna bóveda; puede configurar la ruta más tarde en los ajustes.";;
    ro:novault) echo "Niciun seif selectat – calea poate fi setată ulterior în setări.";;
    de:auto) echo "Agent bei jeder Anmeldung automatisch im Hintergrund starten? (j/n) ";;
    en:auto) echo "Start the agent automatically in the background at every login? (y/n) ";;
    fr:auto) echo "Démarrer l'agent automatiquement en arrière-plan à chaque connexion ? (o/n) ";;
    it:auto) echo "Avviare l'agent automaticamente in background a ogni accesso? (s/n) ";;
    es:auto) echo "¿Iniciar el agente automáticamente en segundo plano en cada inicio de sesión? (s/n) ";;
    ro:auto) echo "Porniți agentul automat în fundal la fiecare autentificare? (d/n) ";;
    de:autook) echo "Autostart beim Anmelden aktiv";; en:autook) echo "Autostart at login active";;
    fr:autook) echo "Démarrage automatique à la connexion actif";; it:autook) echo "Avvio automatico all'accesso attivo";;
    es:autook) echo "Inicio automático al iniciar sesión activo";; ro:autook) echo "Pornirea automată la autentificare este activă";;
    de:syncok) echo "Täglicher Sync eingerichtet um";; en:syncok) echo "Daily sync set up at";; fr:syncok) echo "Synchronisation quotidienne planifiée à";;
    it:syncok) echo "Sincronizzazione giornaliera impostata alle";; es:syncok) echo "Sincronización diaria programada a las";; ro:syncok) echo "Sincronizare zilnică programată la";;
    de:fda) echo "macOS blockiert den Hintergrund-Zugriff auf den Vault (typisch für Dokumente, Schreibtisch oder iCloud Drive). Freigabe: Systemeinstellungen → Datenschutz & Sicherheit → Festplattenvollzugriff → «+» und diese Datei hinzufügen (Cmd+Shift+G):";;
    en:fda) echo "macOS blocks background access to the vault (typical for Documents, Desktop or iCloud Drive). To allow it: System Settings → Privacy & Security → Full Disk Access → «+» and add this file (Cmd+Shift+G):";;
    fr:fda) echo "macOS bloque l'accès en arrière-plan au coffre (typique pour Documents, Bureau ou iCloud Drive). Autorisation : Réglages Système → Confidentialité et sécurité → Accès complet au disque → «+» et ajouter ce fichier (Cmd+Maj+G) :";;
    it:fda) echo "macOS blocca l'accesso in background al vault (tipico per Documenti, Scrivania o iCloud Drive). Per consentirlo: Impostazioni di Sistema → Privacy e sicurezza → Accesso completo al disco → «+» e aggiungere questo file (Cmd+Maiusc+G):";;
    es:fda) echo "macOS bloquea el acceso en segundo plano a la bóveda (típico en Documentos, Escritorio o iCloud Drive). Para permitirlo: Ajustes del Sistema → Privacidad y seguridad → Acceso total al disco → «+» y añada este archivo (Cmd+Mayús+G):";;
    ro:fda) echo "macOS blochează accesul în fundal la seif (tipic pentru Documente, Birou sau iCloud Drive). Permisiune: Setări sistem → Confidențialitate și securitate → Acces complet la disc → «+» și adăugați acest fișier (Cmd+Shift+G):";;
    de:syncerr) echo "Der Hintergrund-Sync meldet einen Fehler (Vault-Pfad unter Einstellungen prüfen):";;
    en:syncerr) echo "The background sync reports an error (check the vault path in the settings):";;
    fr:syncerr) echo "La synchronisation en arrière-plan signale une erreur (vérifier le chemin du coffre dans les paramètres) :";;
    it:syncerr) echo "La sincronizzazione in background segnala un errore (verificare il percorso del vault nelle impostazioni):";;
    es:syncerr) echo "La sincronización en segundo plano informa de un error (compruebe la ruta de la bóveda en los ajustes):";;
    ro:syncerr) echo "Sincronizarea în fundal raportează o eroare (verificați calea seifului în setări):";;
    de:syncgut) echo "Hintergrund-Sync funktioniert";; en:syncgut) echo "Background sync works";; fr:syncgut) echo "La synchronisation en arrière-plan fonctionne";;
    it:syncgut) echo "La sincronizzazione in background funziona";; es:syncgut) echo "La sincronización en segundo plano funciona";; ro:syncgut) echo "Sincronizarea în fundal funcționează";;
    de:fertig) echo "Fertig! Starten mit Doppelklick auf mac/starten_mac.command. Protokolle:";;
    en:fertig) echo "Done! Start it by double-clicking mac/starten_mac.command. Logs:";;
    fr:fertig) echo "Terminé ! Démarrer par double-clic sur mac/starten_mac.command. Journaux :";;
    it:fertig) echo "Fatto! Avviare con doppio clic su mac/starten_mac.command. Registri:";;
    es:fertig) echo "¡Listo! Inícielo con doble clic en mac/starten_mac.command. Registros:";;
    ro:fertig) echo "Gata! Porniți cu dublu clic pe mac/starten_mac.command. Jurnale:";;
    de:jetzt) echo "Agent jetzt öffnen? (j/n) ";; en:jetzt) echo "Open the agent now? (y/n) ";; fr:jetzt) echo "Ouvrir l'agent maintenant ? (o/n) ";;
    it:jetzt) echo "Aprire l'agent ora? (s/n) ";; es:jetzt) echo "¿Abrir el agente ahora? (s/n) ";; ro:jetzt) echo "Deschideți agentul acum? (d/n) ";;
    *:enter) case "$SPRACHE" in de) echo "Enter zum Beenden …";; en) echo "Press Enter to exit …";; fr) echo "Appuyez sur Entrée pour quitter …";;
             it) echo "Premere Invio per uscire …";; es) echo "Pulse Intro para salir …";; ro) echo "Apăsați Enter pentru a ieși …";; esac;;
  esac
}
ja() { [[ "$1" == [jJyYoOsSdD]* ]]; }

echo ""
echo "=== $(t titel) ==="
echo "$(t ordner): $DIR"
echo ""

xattr -dr com.apple.quarantine "$DIR" 2>/dev/null
chmod +x "$DIR"/mac/*.command "$DIR"/start.sh 2>/dev/null

# --- 1. Python ----------------------------------------------------------------
PY=""
for c in python3.13 python3.12 python3.11 python3.10 python3 /usr/local/bin/python3 /opt/homebrew/bin/python3; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
    PY="$(command -v "$c")"; break
  fi
done
if [ -z "$PY" ]; then
  echo "❌ $(t nopy)"
  open "https://www.python.org/downloads/macos/"
  read -r -p "$(t enter)"; exit 1
fi
echo "✅ Python: $PY ($("$PY" --version 2>&1))"

if [ ! -x .venv/bin/python ]; then
  echo "… $(t venv)"
  "$PY" -m venv .venv || { echo "❌ venv"; read -r -p "$(t enter)"; exit 1; }
fi
.venv/bin/python -m pip install -q --upgrade pip >/dev/null 2>&1
.venv/bin/python -m pip install -q -r requirements.txt || { echo "❌ $(t pipfail)"; read -r -p "$(t enter)"; exit 1; }
VPY="$DIR/.venv/bin/python"
echo "✅ $(t pyok)"

# --- 2. Sprache und Vault -------------------------------------------------------------
"$VPY" agent.py sprache "$SPRACHE" >/dev/null
if ! "$VPY" -c "import agent,os,sys; c=agent.load_config(); sys.exit(0 if os.path.isdir(os.path.expanduser(c['vault_path'])) else 1)" 2>/dev/null; then
  PROMPT="$(t vaultdlg)"
  VAULT=$(osascript -e "POSIX path of (choose folder with prompt \"$PROMPT\")" 2>/dev/null)
  if [ -z "$VAULT" ]; then
    echo "⚠️  $(t novault)"
  else
    "$VPY" -c "import agent,sys; c=agent.load_config(); c['vault_path']=sys.argv[1].rstrip('/'); agent.save_config(c)" "$VAULT"
    "$VPY" agent.py sprache "$SPRACHE" >/dev/null
    echo "✅ Vault: $VAULT"
  fi
else
  echo "✅ Vault: $("$VPY" -c "import agent; print(agent.load_config()['vault_path'])")"
fi
"$VPY" agent.py sync 2>&1 | tail -1

# --- 3. LaunchAgents --------------------------------------------------------------------
mkdir -p "$LA" "$LOGDIR"
read -r -p "$(t auto)" AUTO
ja "${AUTO:-n}" && AUTO=j || AUTO=n
"$VPY" - "$DIR" "$LA" "$LOGDIR" "$SYNC_LABEL" "$GUI_LABEL" "$AUTO" <<'PYEOF'
import plistlib, sys, os
sys.path.insert(0, sys.argv[1])
import agent
d, la, logdir, sync_label, gui_label, auto = sys.argv[1:7]
py = os.path.join(d, ".venv", "bin", "python")
h, m = (int(x) for x in agent.load_config().get("sync_zeit", "04:00").split(":"))
sync = {"Label": sync_label, "ProgramArguments": [py, os.path.join(d, "agent.py"), "sync", "--geplant"],
        "WorkingDirectory": d, "StartCalendarInterval": {"Hour": h, "Minute": m},
        "StandardOutPath": os.path.join(logdir, "sync.log"), "StandardErrorPath": os.path.join(logdir, "sync.log")}
with open(os.path.join(la, sync_label + ".plist"), "wb") as f:
    plistlib.dump(sync, f)
gui_path = os.path.join(la, gui_label + ".plist")
if auto == "j":
    gui = {"Label": gui_label, "ProgramArguments": [py, os.path.join(d, "app.py")], "WorkingDirectory": d,
           "RunAtLoad": True, "EnvironmentVariables": {"OBSIDIAN_AGENT_NO_BROWSER": "1"},
           "StandardOutPath": os.path.join(logdir, "gui.log"), "StandardErrorPath": os.path.join(logdir, "gui.log")}
    with open(gui_path, "wb") as f:
        plistlib.dump(gui, f)
elif os.path.exists(gui_path):
    os.remove(gui_path)
print(f"{h:02d}:{m:02d}")
PYEOF
lade() {
  local plist="$LA/$1.plist"
  launchctl bootout "gui/$UIDN/$1" 2>/dev/null || launchctl unload "$plist" 2>/dev/null
  [ -f "$plist" ] && { launchctl bootstrap "gui/$UIDN" "$plist" 2>/dev/null || launchctl load -w "$plist"; }
}
lade "$SYNC_LABEL"
lade "$GUI_LABEL"
echo "✅ $(t syncok) $("$VPY" -c "import agent; print(agent.load_config().get('sync_zeit','04:00'))")"
[ -f "$LA/$GUI_LABEL.plist" ] && echo "✅ $(t autook)"

# --- 4. Hintergrund-Sync testen (Ordnerrechte von macOS) ------------------------------------
: > "$LOGDIR/sync.log"
launchctl kickstart "gui/$UIDN/$SYNC_LABEL" 2>/dev/null
sleep 4
if grep -qiE "Operation not permitted|PermissionError" "$LOGDIR/sync.log"; then
  echo ""
  echo "⚠️  $(t fda)"
  echo "   $("$VPY" -c "import os,sys; print(os.path.realpath(sys.executable))")"
  open "x-apple.systempreferences:com.apple.preference.security?Privacy_AllFiles" 2>/dev/null
elif grep -q "Traceback\|Error" "$LOGDIR/sync.log"; then
  echo "⚠️  $(t syncerr)"
  tail -3 "$LOGDIR/sync.log"
else
  echo "✅ $(t syncgut)"
fi

echo ""
echo "$(t fertig) $LOGDIR"
read -r -p "$(t jetzt)" JETZT
if ja "$JETZT"; then
  exec "$DIR/mac/starten_mac.command"
fi
