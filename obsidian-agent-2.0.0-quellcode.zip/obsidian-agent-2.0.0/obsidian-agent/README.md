# ◆ Obsidian-Agent SDM

Lokale Weboberfläche für Service Delivery Management & Vertrieb auf Basis eines Obsidian-Vaults.
*Local web interface for service delivery management & sales, based on an Obsidian vault.*

📚 Dokumentation, Kurzanleitung und alle Sprachen · documentation, quick installation and all languages: [docs/README.md](docs/README.md)

- Windows: `installieren.bat [de|en|fr|it|es|ro]`
- macOS: `mac/installieren_mac.command [de|en|fr|it|es|ro]`
- Linux: `./start.sh`
- Start: http://127.0.0.1:5055
