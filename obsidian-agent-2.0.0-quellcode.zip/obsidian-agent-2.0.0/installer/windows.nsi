; Obsidian-Agent SDM – Windows-Setup (NSIS 3)
; Seiten: Sprache → Willkommen → Zielverzeichnis & Optionen → Obsidian-Vault → Installation → Abschluss
; Installiert ohne Administratorrechte und richtet Python-Umgebung, Vault und Zeitplan ohne Konsolenfenster ein.
Unicode true
!include "MUI2.nsh"
!include "nsDialogs.nsh"
!include "LogicLib.nsh"

!define APPNAME "Obsidian-Agent SDM"
!define VERSION "2.0.0"
!define UNINSTKEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\ObsidianAgentSDM"
!define STAGE "..\stage\obsidian-agent"

Name "${APPNAME}"
OutFile "..\ObsidianAgent-SDM-Setup.exe"
InstallDir "$LOCALAPPDATA\Programs\Obsidian-Agent"
InstallDirRegKey HKCU "${UNINSTKEY}" "InstallLocation"
RequestExecutionLevel user
SetCompressor /SOLID lzma
BrandingText "${APPNAME} ${VERSION}"
ShowInstDetails hide

Var Dlg
Var DirFeld
Var VaultFeld
Var CbAutostart
Var CbStartmenue
Var CbDesktop
Var CbSpaeter
Var Autostart
Var Startmenue
Var OptDesktop
Var VaultPfad
Var Spaeter

!define MUI_ICON "${STAGE}\static\obsidian-agent.ico"
!define MUI_UNICON "${STAGE}\static\obsidian-agent.ico"
!define MUI_WELCOMEFINISHPAGE_BITMAP "seite.bmp"
!define MUI_UNWELCOMEFINISHPAGE_BITMAP "seite.bmp"
!define MUI_HEADERIMAGE
!define MUI_HEADERIMAGE_RIGHT
!define MUI_HEADERIMAGE_BITMAP "kopf.bmp"
!define MUI_HEADERIMAGE_UNBITMAP "kopf.bmp"
!define MUI_ABORTWARNING
!define MUI_LANGDLL_ALLLANGUAGES

!define MUI_WELCOMEPAGE_TEXT "$(WILLKOMMEN)"
!insertmacro MUI_PAGE_WELCOME
Page custom ZielSeite ZielSeiteVerlassen
Page custom VaultSeite VaultSeiteVerlassen
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_TEXT "$(STARTEN)"
!define MUI_FINISHPAGE_RUN_FUNCTION StarteAgent
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "German"
!insertmacro MUI_LANGUAGE "English"
!insertmacro MUI_LANGUAGE "French"
!insertmacro MUI_LANGUAGE "Italian"
!insertmacro MUI_LANGUAGE "Spanish"
!insertmacro MUI_LANGUAGE "Romanian"
!insertmacro MUI_RESERVEFILE_LANGDLL

!include "texte.nsh"

VIProductVersion "${VERSION}.0"
VIAddVersionKey /LANG=${LANG_GERMAN} "ProductName" "${APPNAME}"
VIAddVersionKey /LANG=${LANG_GERMAN} "FileDescription" "${APPNAME} Setup"
VIAddVersionKey /LANG=${LANG_GERMAN} "FileVersion" "${VERSION}"
VIAddVersionKey /LANG=${LANG_GERMAN} "ProductVersion" "${VERSION}"
VIAddVersionKey /LANG=${LANG_GERMAN} "LegalCopyright" " "

Function .onInit
  !insertmacro MUI_LANGDLL_DISPLAY
  StrCpy $Autostart ${BST_CHECKED}
  StrCpy $Startmenue ${BST_CHECKED}
  StrCpy $OptDesktop ${BST_CHECKED}
  StrCpy $Spaeter ${BST_UNCHECKED}
  ReadRegStr $VaultPfad HKCU "${UNINSTKEY}" "Vault"
  ${If} $VaultPfad == ""
    StrCpy $VaultPfad "$DOCUMENTS\Obsidian"
  ${EndIf}
FunctionEnd

Function un.onInit
  !insertmacro MUI_UNGETLANGUAGE
FunctionEnd

; --- Seite: Zielverzeichnis & Optionen -------------------------------------------
Function ZielSeite
  !insertmacro MUI_HEADER_TEXT "$(ZIEL_TITEL)" "$(ZIEL_UNTER)"
  nsDialogs::Create 1018
  Pop $Dlg
  ${NSD_CreateLabel} 0 0 100% 24u "$(ZIEL_TEXT)"
  Pop $0
  ${NSD_CreateGroupBox} 0 28u 100% 36u "$(ZIEL_GRUPPE)"
  Pop $0
  ${NSD_CreateDirRequest} 8u 42u 228u 13u "$INSTDIR"
  Pop $DirFeld
  ${NSD_CreateBrowseButton} 240u 41u 60u 15u "$(DURCHSUCHEN)"
  Pop $0
  ${NSD_OnClick} $0 ZielWaehlen
  ${NSD_CreateGroupBox} 0 70u 100% 58u "$(OPTIONEN)"
  Pop $0
  ${NSD_CreateCheckbox} 8u 84u 290u 12u "$(OPT_AUTOSTART)"
  Pop $CbAutostart
  ${NSD_SetState} $CbAutostart $Autostart
  ${NSD_CreateCheckbox} 8u 98u 290u 12u "$(OPT_STARTMENUE)"
  Pop $CbStartmenue
  ${NSD_SetState} $CbStartmenue $Startmenue
  ${NSD_CreateCheckbox} 8u 112u 290u 12u "$(OPT_DESKTOP)"
  Pop $CbDesktop
  ${NSD_SetState} $CbDesktop $OptDesktop
  nsDialogs::Show
FunctionEnd

Function ZielWaehlen
  ${NSD_GetText} $DirFeld $0
  nsDialogs::SelectFolderDialog "$(ZIEL_GRUPPE)" "$0"
  Pop $0
  ${If} $0 != error
    ${NSD_SetText} $DirFeld "$0"
  ${EndIf}
FunctionEnd

Function ZielSeiteVerlassen
  ${NSD_GetText} $DirFeld $INSTDIR
  ${NSD_GetState} $CbAutostart $Autostart
  ${NSD_GetState} $CbStartmenue $Startmenue
  ${NSD_GetState} $CbDesktop $OptDesktop
  ${If} $INSTDIR == ""
    Abort
  ${EndIf}
FunctionEnd

; --- Seite: Obsidian-Vault ------------------------------------------------------
Function VaultSeite
  !insertmacro MUI_HEADER_TEXT "$(VAULT_TITEL)" "$(VAULT_UNTER)"
  nsDialogs::Create 1018
  Pop $Dlg
  ${NSD_CreateLabel} 0 0 100% 24u "$(VAULT_TEXT)"
  Pop $0
  ${NSD_CreateGroupBox} 0 28u 100% 36u "$(VAULT_GRUPPE)"
  Pop $0
  ${NSD_CreateDirRequest} 8u 42u 228u 13u "$VaultPfad"
  Pop $VaultFeld
  ${NSD_CreateBrowseButton} 240u 41u 60u 15u "$(DURCHSUCHEN)"
  Pop $0
  ${NSD_OnClick} $0 VaultWaehlen
  ${NSD_CreateCheckbox} 0 72u 100% 12u "$(VAULT_SPAETER)"
  Pop $CbSpaeter
  ${NSD_SetState} $CbSpaeter $Spaeter
  GetDlgItem $0 $HWNDPARENT 1
  SendMessage $0 ${WM_SETTEXT} 0 "STR:$(^InstallBtn)"
  nsDialogs::Show
FunctionEnd

Function VaultWaehlen
  ${NSD_GetText} $VaultFeld $0
  nsDialogs::SelectFolderDialog "$(VAULT_GRUPPE)" "$0"
  Pop $0
  ${If} $0 != error
    ${NSD_SetText} $VaultFeld "$0"
  ${EndIf}
FunctionEnd

Function VaultSeiteVerlassen
  ${NSD_GetText} $VaultFeld $VaultPfad
  ${NSD_GetState} $CbSpaeter $Spaeter
  ${If} $Spaeter != ${BST_CHECKED}
  ${AndIfNot} ${FileExists} "$VaultPfad\*.*"
    MessageBox MB_OK|MB_ICONEXCLAMATION "$(VAULT_FEHLT)"
    Abort
  ${EndIf}
FunctionEnd

Function StarteAgent
  ExecShell "open" "$INSTDIR\start.bat" "" SW_HIDE
FunctionEnd

; --- Installation -------------------------------------------------------------------
Section "Install"
  ; laufende Version beenden, damit der neue Programmstand geladen wird
  nsExec::Exec 'schtasks /End /TN "Obsidian-Agent Weboberflaeche"'
  Pop $0

  DetailPrint "$(KOPIEREN)"
  SetOutPath "$INSTDIR"
  File /r "${STAGE}\*.*"
  WriteUninstaller "$INSTDIR\Uninstall.exe"

  ${If} $Startmenue == ${BST_CHECKED}
    CreateDirectory "$SMPROGRAMS\${APPNAME}"
    CreateShortcut "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk" "$INSTDIR\start.bat" "" "$INSTDIR\static\obsidian-agent.ico" 0 SW_SHOWMINIMIZED
    CreateShortcut "$SMPROGRAMS\${APPNAME}\$(GUIDE).lnk" "$INSTDIR\docs\html\$(GUIDEFILE).html"
    CreateShortcut "$SMPROGRAMS\${APPNAME}\$(DEINST).lnk" "$INSTDIR\Uninstall.exe"
  ${EndIf}
  ${If} $OptDesktop == ${BST_CHECKED}
    CreateShortcut "$DESKTOP\${APPNAME}.lnk" "$INSTDIR\start.bat" "" "$INSTDIR\static\obsidian-agent.ico" 0 SW_SHOWMINIMIZED
  ${EndIf}

  WriteRegStr HKCU "${UNINSTKEY}" "DisplayName" "${APPNAME}"
  WriteRegStr HKCU "${UNINSTKEY}" "DisplayVersion" "${VERSION}"
  WriteRegStr HKCU "${UNINSTKEY}" "DisplayIcon" "$INSTDIR\static\obsidian-agent.ico"
  WriteRegStr HKCU "${UNINSTKEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "${UNINSTKEY}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegStr HKCU "${UNINSTKEY}" "Language" "$(CODE)"
  WriteRegDWORD HKCU "${UNINSTKEY}" "NoModify" 1
  WriteRegDWORD HKCU "${UNINSTKEY}" "NoRepair" 1
  ${If} $Spaeter != ${BST_CHECKED}
    WriteRegStr HKCU "${UNINSTKEY}" "Vault" "$VaultPfad"
  ${EndIf}

  ; Einrichtung ohne Konsolenfenster: Python-Umgebung, Sprache, Vault, geplante Aufgaben
  DetailPrint "$(EINRICHTEN)"
  StrCpy $1 '-Sprache $(CODE) -Still'
  ${If} $Spaeter != ${BST_CHECKED}
    StrCpy $1 '$1 -Vault "$VaultPfad"'
  ${EndIf}
  ${If} $Autostart != ${BST_CHECKED}
    StrCpy $1 '$1 -OhneAutostart'
  ${EndIf}
  nsExec::ExecToLog 'powershell -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\installieren.ps1" $1'
  Pop $0
  ${If} $0 == 2
    MessageBox MB_OK|MB_ICONEXCLAMATION "$(KEIN_PYTHON)"
    ExecShell "open" "https://www.python.org/downloads/windows/"
  ${ElseIf} $0 == 3
    MessageBox MB_OK|MB_ICONEXCLAMATION "$(KEIN_INTERNET)"
  ${ElseIf} $0 != 0
    MessageBox MB_OK|MB_ICONEXCLAMATION "$(EINRICHTUNG_FEHLER)"
  ${EndIf}
SectionEnd

; --- Deinstallation -----------------------------------------------------------------
Section "Uninstall"
  nsExec::Exec 'powershell -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\deinstallieren.ps1" -Still'
  Pop $0
  ; nur eigene Dateien entfernen; der Obsidian-Vault liegt nie hier und bleibt unverändert
  RMDir /r "$INSTDIR\.venv"
  RMDir /r "$INSTDIR\__pycache__"
  RMDir /r "$INSTDIR\templates"
  RMDir /r "$INSTDIR\static"
  RMDir /r "$INSTDIR\i18n"
  RMDir /r "$INSTDIR\docs"
  RMDir /r "$INSTDIR\mac"
  Delete "$INSTDIR\agent.py"
  Delete "$INSTDIR\app.py"
  Delete "$INSTDIR\i18n.py"
  Delete "$INSTDIR\vorlagen.py"
  Delete "$INSTDIR\hintergrund.pyw"
  Delete "$INSTDIR\requirements.txt"
  Delete "$INSTDIR\README.md"
  Delete "$INSTDIR\start.bat"
  Delete "$INSTDIR\start.sh"
  Delete "$INSTDIR\installieren.bat"
  Delete "$INSTDIR\installieren.ps1"
  Delete "$INSTDIR\deinstallieren.bat"
  Delete "$INSTDIR\deinstallieren.ps1"
  Delete "$INSTDIR\config.json"
  Delete "$INSTDIR\planer.db"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir "$INSTDIR"
  RMDir /r "$SMPROGRAMS\${APPNAME}"
  Delete "$DESKTOP\${APPNAME}.lnk"
  DeleteRegKey HKCU "${UNINSTKEY}"
SectionEnd
