"""
Baut ObsidianAgent-SDM.pkg (macOS Product Archive, xar-Format) ohne Apple-Werkzeuge.

Aufbau (wie productbuild):
  Distribution                      Installer-Ablauf, Titel, Willkommenstext
  Resources/<sprache>.lproj/*.html  Willkommen/Abschluss je Sprache
  obsidian-agent.pkg/PackageInfo    Komponente ohne Payload (nur Skripte)
  obsidian-agent.pkg/Scripts        gzip-cpio mit preinstall, postinstall, payload.tar.gz

Die Programmdateien werden vom postinstall-Skript als angemeldeter Benutzer nach
~/Applications/Obsidian-Agent entpackt; danach öffnet sich die Einrichtung im Terminal.
"""
import datetime as dt
import gzip
import hashlib
import io
import os
import struct
import subprocess
import sys
import tarfile
import tempfile
import zlib
from pathlib import Path
from xml.sax.saxutils import escape

HIER = Path(__file__).resolve().parent
STAGE = HIER.parent / "stage" / "obsidian-agent"
AUSGABE = HIER.parent / "ObsidianAgent-SDM.pkg"
ID = "ch.obsidian-agent.sdm"
VERSION = "2.0.0"

PREINSTALL = r"""#!/bin/bash
# Laufenden Agent des angemeldeten Benutzers beenden, damit der neue Programmstand geladen wird.
BENUTZER=$(stat -f%Su /dev/console)
[ -z "$BENUTZER" ] || [ "$BENUTZER" = "root" ] || [ "$BENUTZER" = "loginwindow" ] && exit 0
UIDN=$(id -u "$BENUTZER")
launchctl bootout "gui/$UIDN/ch.obsidian-agent.gui" 2>/dev/null
for P in $(lsof -ti tcp:5055 -sTCP:LISTEN 2>/dev/null); do kill "$P" 2>/dev/null; done
exit 0
"""

POSTINSTALL = r"""#!/bin/bash
# Programm als angemeldeter Benutzer nach ~/Applications/Obsidian-Agent entpacken
# (bestehende config.json, planer.db und .venv bleiben erhalten) und Einrichtung öffnen.
SKRIPTE="$(cd "$(dirname "$0")" && pwd)"
BENUTZER=$(stat -f%Su /dev/console)
if [ -z "$BENUTZER" ] || [ "$BENUTZER" = "root" ] || [ "$BENUTZER" = "loginwindow" ]; then
  echo "Obsidian-Agent: no console user" >&2
  exit 1
fi
UIDN=$(id -u "$BENUTZER")
HEIM=$(dscl . -read "/Users/$BENUTZER" NFSHomeDirectory | awk '{print $2}')
ZIEL="$HEIM/Applications/Obsidian-Agent"
sudo -u "$BENUTZER" mkdir -p "$ZIEL" || exit 1
sudo -u "$BENUTZER" tar -xzf "$SKRIPTE/payload.tar.gz" -C "$ZIEL" || exit 1
xattr -dr com.apple.quarantine "$ZIEL" 2>/dev/null
chmod +x "$ZIEL"/mac/*.command "$ZIEL"/start.sh 2>/dev/null
launchctl asuser "$UIDN" sudo -u "$BENUTZER" open -a Terminal "$ZIEL/mac/installieren_mac.command"
exit 0
"""

TEXTE = {
    "de": ("Obsidian-Agent SDM – lokale Weboberfläche für Service Delivery Management & Vertrieb.",
           "Das Programm wird nach <b>~/Applications/Obsidian-Agent</b> installiert. Danach öffnet sich ein Terminal-Fenster für die Einrichtung: Python-Umgebung, Wahl des Obsidian-Vaults und automatischer Start.",
           "Voraussetzung: Python 3.9 oder neuer (python.org oder <code>brew install python</code>).",
           "Die Einrichtung läuft jetzt im Terminal-Fenster. Danach ist der Agent unter <b>http://127.0.0.1:5055</b> erreichbar. Anleitung: ~/Applications/Obsidian-Agent/docs/"),
    "en": ("Obsidian-Agent SDM – local web interface for service delivery management & sales.",
           "The program is installed to <b>~/Applications/Obsidian-Agent</b>. A Terminal window then opens for the setup: Python environment, choice of the Obsidian vault and automatic start.",
           "Requirement: Python 3.9 or newer (python.org or <code>brew install python</code>).",
           "The setup now runs in the Terminal window. Afterwards the agent is available at <b>http://127.0.0.1:5055</b>. Guide: ~/Applications/Obsidian-Agent/docs/"),
    "fr": ("Obsidian-Agent SDM – interface web locale pour le Service Delivery Management et la vente.",
           "Le programme est installé dans <b>~/Applications/Obsidian-Agent</b>. Une fenêtre Terminal s'ouvre ensuite pour la configuration : environnement Python, choix du coffre Obsidian et démarrage automatique.",
           "Prérequis : Python 3.9 ou plus récent (python.org ou <code>brew install python</code>).",
           "La configuration se poursuit dans la fenêtre Terminal. L'agent est ensuite accessible à l'adresse <b>http://127.0.0.1:5055</b>. Guide : ~/Applications/Obsidian-Agent/docs/"),
    "it": ("Obsidian-Agent SDM – interfaccia web locale per il Service Delivery Management e le vendite.",
           "Il programma viene installato in <b>~/Applications/Obsidian-Agent</b>. Poi si apre una finestra del Terminale per la configurazione: ambiente Python, scelta del vault Obsidian e avvio automatico.",
           "Requisito: Python 3.9 o successivo (python.org oppure <code>brew install python</code>).",
           "La configurazione prosegue nella finestra del Terminale. Poi l'agent è raggiungibile su <b>http://127.0.0.1:5055</b>. Guida: ~/Applications/Obsidian-Agent/docs/"),
    "es": ("Obsidian-Agent SDM – interfaz web local para la gestión de servicios (SDM) y las ventas.",
           "El programa se instala en <b>~/Applications/Obsidian-Agent</b>. Después se abre una ventana de Terminal para la configuración: entorno de Python, elección de la bóveda de Obsidian e inicio automático.",
           "Requisito: Python 3.9 o superior (python.org o <code>brew install python</code>).",
           "La configuración continúa en la ventana de Terminal. Después el agente está disponible en <b>http://127.0.0.1:5055</b>. Guía: ~/Applications/Obsidian-Agent/docs/"),
    "ro": ("Obsidian-Agent SDM – interfață web locală pentru Service Delivery Management și vânzări.",
           "Programul se instalează în <b>~/Applications/Obsidian-Agent</b>. Apoi se deschide o fereastră Terminal pentru configurare: mediul Python, alegerea seifului Obsidian și pornirea automată.",
           "Cerință: Python 3.9 sau mai nou (python.org sau <code>brew install python</code>).",
           "Configurarea continuă în fereastra Terminal. Apoi agentul este disponibil la <b>http://127.0.0.1:5055</b>. Ghid: ~/Applications/Obsidian-Agent/docs/"),
}
LPROJ = {"de": "de", "en": "en", "fr": "fr", "it": "it", "es": "es", "ro": "ro"}


def html(titel: str, *absaetze: str) -> bytes:
    body = "".join(f"<p>{a}</p>" for a in absaetze)
    return (f'<!DOCTYPE html><html><head><meta charset="utf-8"><title>{escape(titel)}</title>'
            f'<style>body{{font:13px -apple-system,sans-serif}}</style></head><body>{body}</body></html>').encode()


def payload_tar() -> bytes:
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz", format=tarfile.PAX_FORMAT) as tar:
        for p in sorted(STAGE.rglob("*")):
            rel = p.relative_to(STAGE).as_posix()
            ti = tar.gettarinfo(str(p), arcname=rel)
            ti.uid = ti.gid = 0
            ti.uname = ti.gname = ""
            ausf = p.suffix in (".command", ".sh")
            ti.mode = 0o755 if (p.is_dir() or ausf) else 0o644
            if p.is_file():
                with open(p, "rb") as f:
                    tar.addfile(ti, f)
            else:
                tar.addfile(ti)
    return buf.getvalue()


def scripts_cpio(payload: bytes) -> bytes:
    with tempfile.TemporaryDirectory() as d:
        d = Path(d)
        (d / "preinstall").write_text(PREINSTALL)
        (d / "postinstall").write_text(POSTINSTALL)
        (d / "payload.tar.gz").write_bytes(payload)
        os.chmod(d / "preinstall", 0o755)
        os.chmod(d / "postinstall", 0o755)
        os.chmod(d / "payload.tar.gz", 0o644)
        os.chmod(d, 0o755)
        liste = ".\n./payload.tar.gz\n./postinstall\n./preinstall\n"
        cpio = subprocess.run(["cpio", "-o", "--format=odc", "--owner=0:0", "--quiet"], input=liste.encode(),
                              cwd=d, capture_output=True, check=True).stdout
    return gzip.compress(cpio, mtime=0)


def distribution() -> bytes:
    return f"""<?xml version="1.0" encoding="utf-8"?>
<installer-gui-script minSpecVersion="2">
    <title>Obsidian-Agent SDM</title>
    <welcome file="Welcome.html" mime-type="text/html"/>
    <conclusion file="Conclusion.html" mime-type="text/html"/>
    <options customize="never" require-scripts="true" hostArchitectures="x86_64,arm64"/>
    <domains enable_anywhere="false" enable_currentUserHome="false" enable_localSystem="true"/>
    <volume-check><allowed-os-versions><os-version min="11.0"/></allowed-os-versions></volume-check>
    <choices-outline>
        <line choice="default"><line choice="{ID}"/></line>
    </choices-outline>
    <choice id="default"/>
    <choice id="{ID}" visible="false"><pkg-ref id="{ID}"/></choice>
    <pkg-ref id="{ID}" version="{VERSION}" onConclusion="none">#obsidian-agent.pkg</pkg-ref>
</installer-gui-script>
""".encode()


def package_info() -> bytes:
    return f"""<?xml version="1.0" encoding="utf-8"?>
<pkg-info overwrite-permissions="true" relocatable="false" identifier="{ID}" postinstall-action="none" version="{VERSION}" format-version="2" generator-version="InstallCmds-1" auth="root" install-location="/">
    <scripts>
        <preinstall file="./preinstall"/>
        <postinstall file="./postinstall"/>
    </scripts>
</pkg-info>
""".encode()


# --- xar -------------------------------------------------------------------------
class Xar:
    def __init__(self):
        self.heap = bytearray(20)  # Platz für die TOC-Prüfsumme (SHA-1) an Offset 0
        self.next_id = 1
        self.zeit = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")

    def _id(self) -> int:
        i = self.next_id
        self.next_id += 1
        return i

    def datei(self, name: str, daten: bytes, mode: str = "0644") -> str:
        off = len(self.heap)
        self.heap += daten
        sha = hashlib.sha1(daten).hexdigest()
        return (f'<file id="{self._id()}"><data><length>{len(daten)}</length>'
                f'<encoding style="application/octet-stream"/><offset>{off}</offset><size>{len(daten)}</size>'
                f'<extracted-checksum style="sha1">{sha}</extracted-checksum>'
                f'<archived-checksum style="sha1">{sha}</archived-checksum></data>'
                f'<ctime>{self.zeit}Z</ctime><mtime>{self.zeit}Z</mtime><atime>{self.zeit}Z</atime>'
                f'<group>wheel</group><gid>0</gid><user>root</user><uid>0</uid><mode>{mode}</mode>'
                f'<type>file</type><name>{escape(name)}</name></file>')

    def ordner(self, name: str, kinder: list[str]) -> str:
        return (f'<file id="{self._id()}"><ctime>{self.zeit}Z</ctime><mtime>{self.zeit}Z</mtime>'
                f'<atime>{self.zeit}Z</atime><group>wheel</group><gid>0</gid><user>root</user><uid>0</uid>'
                f'<mode>0755</mode><type>directory</type><name>{escape(name)}</name>{"".join(kinder)}</file>')

    def schreiben(self, eintraege: list[str], ziel: Path):
        toc = ('<?xml version="1.0" encoding="UTF-8"?>\n<xar><toc>'
               '<checksum style="sha1"><offset>0</offset><size>20</size></checksum>'
               f'<creation-time>{self.zeit}</creation-time>{"".join(eintraege)}</toc></xar>').encode()
        toc_z = zlib.compress(toc, 9)
        self.heap[0:20] = hashlib.sha1(toc_z).digest()
        kopf = struct.pack(">IHHQQI", 0x78617221, 28, 1, len(toc_z), len(toc), 1)
        ziel.write_bytes(kopf + toc_z + bytes(self.heap))


def main():
    if not STAGE.is_dir():
        sys.exit(f"Stage fehlt: {STAGE}")
    x = Xar()
    eintraege = [x.datei("Distribution", distribution())]
    lproj = []
    for code, (titel, a, b, fertig) in TEXTE.items():
        lproj.append(x.ordner(f"{LPROJ[code]}.lproj", [
            x.datei("Welcome.html", html(titel, f"<b>{titel}</b>", a, b)),
            x.datei("Conclusion.html", html(titel, fertig)),
        ]))
    eintraege.append(x.ordner("Resources", lproj))
    eintraege.append(x.ordner("obsidian-agent.pkg", [
        x.datei("PackageInfo", package_info()),
        x.datei("Scripts", scripts_cpio(payload_tar())),
    ]))
    x.schreiben(eintraege, AUSGABE)
    print(AUSGABE, AUSGABE.stat().st_size)


if __name__ == "__main__":
    main()
